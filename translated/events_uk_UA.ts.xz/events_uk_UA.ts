<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk" sourcelanguage="en">
  <context>
    <name>/components/0/enums/calibration_action_t/entries/0/description</name>
    <message>
      <source>Side already completed, switch to one of the remaining sides</source>
      <translation>Сторону укомплектовано, перейдіть до однієї зі сторін що залишилися</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_action_t/entries/1/description</name>
    <message>
      <source>Switch to next orientation</source>
      <translation>Перейдіть до наступної орієнтації</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_action_t/entries/2/description</name>
    <message>
      <source>Rotate as shown</source>
      <translation>Обертайте як показано</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_action_t/entries/3/description</name>
    <message>
      <source>Hold still</source>
      <translation>Тримати нерухомо</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_result_t/entries/0/description</name>
    <message>
      <source>Success</source>
      <translation>Успіх</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_result_t/entries/1/description</name>
    <message>
      <source>Failed</source>
      <translation>Невдалий</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_result_t/entries/2/description</name>
    <message>
      <source>Aborted</source>
      <translation>Скасований</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/1/description</name>
    <message>
      <source>Tail Down</source>
      <translation>Скласти хвіст</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/16/description</name>
    <message>
      <source>Upside Down</source>
      <translation>Перевернутий</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/2/description</name>
    <message>
      <source>Nose Down</source>
      <translation>Ніс донизу</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/32/description</name>
    <message>
      <source>Down</source>
      <translation>Донизу</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/4/description</name>
    <message>
      <source>Left Side Down</source>
      <translation>Лівий бік донизу</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/8/description</name>
    <message>
      <source>Right Side Down</source>
      <translation>Правий бік донизу</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/1/description</name>
    <message>
      <source>Accelerometer</source>
      <translation>Акселерометр</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/16/description</name>
    <message>
      <source>Airspeed</source>
      <translation>Швидкість польоту</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/2/description</name>
    <message>
      <source>Magnetometer</source>
      <translation>Магнетометр</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/32/description</name>
    <message>
      <source>RC</source>
      <translation>Пульт</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/4/description</name>
    <message>
      <source>Gyroscope</source>
      <translation>Гіроскоп</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/8/description</name>
    <message>
      <source>Level</source>
      <translation>Рівень</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1100/message</name>
    <message>
      <source>Calibration progress: {2}%</source>
      <translation>Прогрес калібрування: {2}%</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1101/message</name>
    <message>
      <source>Orientation detected: {1}</source>
      <translation>Орієнтацію знайдено: {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1102/message</name>
    <message>
      <source>Orientation Complete: {1}, next step: {2}</source>
      <translation>Орієнтацію завершено: {1}, наступний крок: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1103/message</name>
    <message>
      <source>Calibration Complete: {1}</source>
      <translation>Калібрування завершено: {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/1/description</name>
    <message>
      <source>stick gesture</source>
      <translation type="unfinished">stick gesture</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/13/description</name>
    <message>
      <source>RC button</source>
      <translation type="unfinished">RC button</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/14/description</name>
    <message>
      <source>failsafe</source>
      <translation>аварійний режим</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/2/description</name>
    <message>
      <source>RC switch</source>
      <translation type="unfinished">RC switch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/3/description</name>
    <message>
      <source>internal command</source>
      <translation>внутрішня команда</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/4/description</name>
    <message>
      <source>external command</source>
      <translation>зовнішня команда</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/5/description</name>
    <message>
      <source>mission start</source>
      <translation>початок місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/6/description</name>
    <message>
      <source>landing</source>
      <translation>приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/7/description</name>
    <message>
      <source>preflight inaction</source>
      <translation type="unfinished">preflight inaction</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/8/description</name>
    <message>
      <source>kill switch</source>
      <translation>ліквідувати перемикач</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/0/description</name>
    <message>
      <source>Init</source>
      <translation>Init</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/1/description</name>
    <message>
      <source>Standby</source>
      <translation>Режим очікування</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/2/description</name>
    <message>
      <source>Armed</source>
      <translation>Активований</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/3/description</name>
    <message>
      <source>Standby Error</source>
      <translation>Помилка режиму очікування</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/4/description</name>
    <message>
      <source>Shutdown</source>
      <translation>Вимкнути</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/5/description</name>
    <message>
      <source>In-air Restore</source>
      <translation>In-air відновлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/0/description</name>
    <message>
      <source>Battery has deep discharged</source>
      <translation>Батарея глибоко розряджена</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/1/description</name>
    <message>
      <source>Battery detected voltage spikes</source>
      <translation>Батарея виявила стрибки напруги</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/10/description</name>
    <message>
      <source>Battery failed to arm</source>
      <translation type="unfinished">Battery failed to arm</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/2/description</name>
    <message>
      <source>One or more battery cells have failed</source>
      <translation>Одна або більше комірок батареї відмовила</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/3/description</name>
    <message>
      <source>Battery reported over-current</source>
      <translation>Батарея повідомляє про надмірну напругу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/4/description</name>
    <message>
      <source>Battery has reached a critical temperature which can result in a critical failure</source>
      <translation>Батарея досягла критичної температури, що може призвести до критичної поломки</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/5/description</name>
    <message>
      <source>Battery temperature is below operating range</source>
      <translation>Температура батареї нижче за робочий рівень</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/6/description</name>
    <message>
      <source>Voltage mismatch, use equally charged batteries</source>
      <translation type="unfinished">Voltage mismatch, use equally charged batteries</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/7/description</name>
    <message>
      <source>Battery firmware is not compatible with current autopilot firmware</source>
      <translation>Прошивка батареї не є сумісною з поточною прошивкою автопілота</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/8/description</name>
    <message>
      <source>Battery model is not supported by the system</source>
      <translation>Модель батареї не підтримується системою</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/9/description</name>
    <message>
      <source>Battery reported an hardware problem</source>
      <translation>Батарея повідомляє про проблему обладнання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/0/description</name>
    <message>
      <source>detected over current</source>
      <translation>виявлено надвисоку напругу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/1/description</name>
    <message>
      <source>detected over voltage</source>
      <translation>виявлено надвисокий вольтаж</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/2/description</name>
    <message>
      <source>Motor has reached a critical temperature</source>
      <translation>Мотор досягнув критичної температури</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/3/description</name>
    <message>
      <source>Motor RPM is exceeding the limits</source>
      <translation>Оберти мотору перевищують ліміт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/4/description</name>
    <message>
      <source>received an invalid control command</source>
      <translation>отримано невірну контрольну команду</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/5/description</name>
    <message>
      <source>Motor stalled</source>
      <translation>Мотор зупинився</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/6/description</name>
    <message>
      <source>detected a generic hardware failure</source>
      <translation>виявлено загальну помилку обладнання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/7/description</name>
    <message>
      <source>Motor is over-heating</source>
      <translation>Мотор перегрівається</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/8/description</name>
    <message>
      <source>is over-heating</source>
      <translation>перегрівається</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/9/description</name>
    <message>
      <source>reached a critical temperature</source>
      <translation>досягнув критичної температури</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/0/description</name>
    <message>
      <source/>
      <translation type="unfinished"/>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/1/description</name>
    <message>
      <source>warning</source>
      <translation>попередження</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/10/description</name>
    <message>
      <source>terminate</source>
      <translation>закінчити</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/2/description</name>
    <message>
      <source>Position mode</source>
      <translation>Позиційний режим</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/3/description</name>
    <message>
      <source>Altitude mode</source>
      <translation>Висотний режим</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/4/description</name>
    <message>
      <source>Stabilized mode</source>
      <translation>Стабілізаційний режим</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/5/description</name>
    <message>
      <source>Hold</source>
      <translation>Тримати</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/6/description</name>
    <message>
      <source>RTL</source>
      <translation>режим RTL (Return to Launch - повернення до точки зльоту)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/7/description</name>
    <message>
      <source>Land</source>
      <translation>Приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/8/description</name>
    <message>
      <source>Descend</source>
      <translation>Зниження</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/9/description</name>
    <message>
      <source>disarm</source>
      <translation>деактивувати</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/0/description</name>
    <message>
      <source/>
      <translation type="unfinished"/>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/1/description</name>
    <message>
      <source>Manual control loss</source>
      <translation>Ручний контроль втрат</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/2/description</name>
    <message>
      <source>GCS connection loss</source>
      <translation>GCS з'єднання втрачено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/3/description</name>
    <message>
      <source>Low battery level</source>
      <translation>Низький рівень батареї</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/4/description</name>
    <message>
      <source>Critical battery level</source>
      <translation>Критичний рівень батареї</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/5/description</name>
    <message>
      <source>Emergency battery level</source>
      <translation>Аварійний заряд батареї</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/6/description</name>
    <message>
      <source>Remaining flight time low</source>
      <translation>Залишилось мало польотного часу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1/description</name>
    <message>
      <source>None</source>
      <translation>Нічого</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1024/description</name>
    <message>
      <source>Logging</source>
      <translation>Ведення журналу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1048576/description</name>
    <message>
      <source>System</source>
      <translation>Система</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1073741824/description</name>
    <message>
      <source>Open Drone ID system</source>
      <translation>Відкрити систему Drone ID</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/128/description</name>
    <message>
      <source>Remote Control (RC or Joystick)</source>
      <translation>Пульт керування (RC або джойстик)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/131072/description</name>
    <message>
      <source>Local position estimate</source>
      <translation>Оцінка локальної позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/134217728/description</name>
    <message>
      <source>Magnetometer</source>
      <translation>Магнетометр</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/16/description</name>
    <message>
      <source>Optical flow</source>
      <translation>Оптичний потік</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/16384/description</name>
    <message>
      <source>Attitude controller</source>
      <translation>Контролер стану орієнтації</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/16777216/description</name>
    <message>
      <source>Global position estimate</source>
      <translation>Оцінка глобальної позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2/description</name>
    <message>
      <source>Absolute pressure</source>
      <translation>Абсолютний тиск</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2048/description</name>
    <message>
      <source>Battery</source>
      <translation>Батарея</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2097152/description</name>
    <message>
      <source>Camera</source>
      <translation>Камера</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2147483648/description</name>
    <message>
      <source>Traffic Avoidance (ADSB/FLARM)</source>
      <translation type="unfinished">Traffic Avoidance (ADSB/FLARM)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/256/description</name>
    <message>
      <source>Motors/ESCs</source>
      <translation>Мотори/ESCs</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/262144/description</name>
    <message>
      <source>Mission</source>
      <translation>Місія</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/268435456/description</name>
    <message>
      <source>Accelerometer</source>
      <translation>Акселерометр</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/32/description</name>
    <message>
      <source>Vision position estimate</source>
      <translation>Оцінка огляду з позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/32768/description</name>
    <message>
      <source>Position controller</source>
      <translation>Контролер позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/33554432/description</name>
    <message>
      <source>Storage</source>
      <translation>Сховище</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/4/description</name>
    <message>
      <source>Differential pressure</source>
      <translation>Диференціальний тиск</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/4096/description</name>
    <message>
      <source>Communication links</source>
      <translation>Комунікаційні зв'язки</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/4194304/description</name>
    <message>
      <source>Gimbal</source>
      <translation>Підвіс камери</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/512/description</name>
    <message>
      <source>UTM</source>
      <translation>UTM (Безпілотне управління дорожнім рухом)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/524288/description</name>
    <message>
      <source>Avoidance</source>
      <translation>Уникнення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/536870912/description</name>
    <message>
      <source>Gyroscope</source>
      <translation>Гіроскоп</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/64/description</name>
    <message>
      <source>Distance sensor</source>
      <translation>Сенсор відстані</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/65536/description</name>
    <message>
      <source>Attitude estimate</source>
      <translation>Оцінювання стану орієнтації</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/67108864/description</name>
    <message>
      <source>Parachute</source>
      <translation>Парашут</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/8/description</name>
    <message>
      <source>GPS</source>
      <translation>GPS</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/8192/description</name>
    <message>
      <source>Rate controller</source>
      <translation>Коефіцієнт контролера</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/8388608/description</name>
    <message>
      <source>Payload</source>
      <translation>Боєкомплект</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1/description</name>
    <message>
      <source>Fully manual mode (w/o any controller support)</source>
      <translation>Повністю ручний режим (без будь-якої підтримки контролером)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1024/description</name>
    <message>
      <source>Acro</source>
      <translation>Режим Acro</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1048576/description</name>
    <message>
      <source>Precision Land</source>
      <translation>Точність приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1073741824/description</name>
    <message>
      <source>External 8</source>
      <translation>Зовнішній 8</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/128/description</name>
    <message>
      <source>Course</source>
      <translation type="unfinished">Course</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/131072/description</name>
    <message>
      <source>Takeoff</source>
      <translation>Зліт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/134217728/description</name>
    <message>
      <source>External 5</source>
      <translation>Зовнішній 5</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/16/description</name>
    <message>
      <source>Loiter</source>
      <translation>Баражувати</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/16384/description</name>
    <message>
      <source>Offboard</source>
      <translation>Режим Offboard</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/16777216/description</name>
    <message>
      <source>External 2</source>
      <translation>Зовнішній 2</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/2/description</name>
    <message>
      <source>Altitude mode</source>
      <translation>Режим висоти</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/2097152/description</name>
    <message>
      <source>Orbit</source>
      <translation>Орбіта</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/256/description</name>
    <message>
      <source>Altitude Cruise</source>
      <translation type="unfinished">Altitude Cruise</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/262144/description</name>
    <message>
      <source>Land</source>
      <translation>Приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/268435456/description</name>
    <message>
      <source>External 6</source>
      <translation>Зовнішній 6</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/32/description</name>
    <message>
      <source>RTL</source>
      <translation>RTL (Return to Launch - повернення до точки зльоту)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/32768/description</name>
    <message>
      <source>Stabilized</source>
      <translation>Стабілізувати</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/33554432/description</name>
    <message>
      <source>External 3</source>
      <translation>Зовнішній 3</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/4/description</name>
    <message>
      <source>Position mode</source>
      <translation>Позиційний режим</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/4194304/description</name>
    <message>
      <source>VTOL Takeoff</source>
      <translation>Вертикальний зліт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/524288/description</name>
    <message>
      <source>Follow Target</source>
      <translation>Слідувати за ціллю</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/536870912/description</name>
    <message>
      <source>External 7</source>
      <translation>Зовнішній 7</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/64/description</name>
    <message>
      <source>Position Slow</source>
      <translation type="unfinished">Position Slow</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/67108864/description</name>
    <message>
      <source>External 4</source>
      <translation>Зовнішній 4</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/8/description</name>
    <message>
      <source>Mission mode</source>
      <translation>Режим місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/8388608/description</name>
    <message>
      <source>External 1</source>
      <translation>Зовнішній 1</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/0/description</name>
    <message>
      <source>Manual</source>
      <translation>Ручний</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/1/description</name>
    <message>
      <source>Altitude control</source>
      <translation>Контроль висоти</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/10/description</name>
    <message>
      <source>Takeoff</source>
      <translation>Зліт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/11/description</name>
    <message>
      <source>Land</source>
      <translation>Приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/12/description</name>
    <message>
      <source>Follow Target</source>
      <translation>Переслідувати ціль</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/13/description</name>
    <message>
      <source>Precision Landing</source>
      <translation>Точність приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/14/description</name>
    <message>
      <source>Orbit</source>
      <translation>Орбіта</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/15/description</name>
    <message>
      <source>Vtol Takeoff</source>
      <translation>Вертикальний зліт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/16/description</name>
    <message>
      <source>External 1</source>
      <translation>Зовнішній 1</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/17/description</name>
    <message>
      <source>External 2</source>
      <translation>Зовнішній 2</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/18/description</name>
    <message>
      <source>External 3</source>
      <translation>Зовнішній 3</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/19/description</name>
    <message>
      <source>External 4</source>
      <translation>Зовнішній 4</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/2/description</name>
    <message>
      <source>Position control</source>
      <translation>Контроль позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/20/description</name>
    <message>
      <source>External 5</source>
      <translation>Зовнішній 5</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/21/description</name>
    <message>
      <source>External 6</source>
      <translation>Зовнішній 6</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/22/description</name>
    <message>
      <source>External 7</source>
      <translation>Зовнішній 7</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/23/description</name>
    <message>
      <source>External 8</source>
      <translation>Зовнішній 8</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/24/description</name>
    <message>
      <source>Altitude Cruise</source>
      <translation type="unfinished">Altitude Cruise</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/25/description</name>
    <message>
      <source>Course</source>
      <translation type="unfinished">Course</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/255/description</name>
    <message>
      <source>[Unknown]</source>
      <translation>[Невідомий]</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/3/description</name>
    <message>
      <source>Mission</source>
      <translation>Місія</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/4/description</name>
    <message>
      <source>Hold</source>
      <translation>Тримати</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/5/description</name>
    <message>
      <source>RTL</source>
      <translation>режим RTL (Return to Launch - повернення до точки зльоту)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/6/description</name>
    <message>
      <source>Acro</source>
      <translation>Режим Acro</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/7/description</name>
    <message>
      <source>Offboard</source>
      <translation>Режим Offboard</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/8/description</name>
    <message>
      <source>Stabilized</source>
      <translation>Стабілізований</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/9/description</name>
    <message>
      <source>Position Slow</source>
      <translation>Повільний режим позиціювання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/1/description</name>
    <message>
      <source>No data</source>
      <translation>Немає даних</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/16/description</name>
    <message>
      <source>High Error Density</source>
      <translation>Висока щільність помилок</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/2/description</name>
    <message>
      <source>Stale data</source>
      <translation>Stale данні</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/4/description</name>
    <message>
      <source>Timeout</source>
      <translation>Тайм-аут</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/8/description</name>
    <message>
      <source>High Error Count</source>
      <translation>Висока кількість помилок</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_type_t/entries/0/description</name>
    <message>
      <source>Accelerometer</source>
      <translation>Акселерометр</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_type_t/entries/1/description</name>
    <message>
      <source>Gyroscope</source>
      <translation>Гіроскоп</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_type_t/entries/2/description</name>
    <message>
      <source>Magnetometer</source>
      <translation>Магнетометр</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/suggested_action_t/entries/0/description</name>
    <message>
      <source/>
      <translation type="unfinished"/>
    </message>
  </context>
  <context>
    <name>/components/1/enums/suggested_action_t/entries/1/description</name>
    <message>
      <source>Land now!</source>
      <translation>Приземляйтеся зараз!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/suggested_action_t/entries/2/description</name>
    <message>
      <source>Reduce throttle!</source>
      <translation>Зменште тягу!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10011251/message</name>
    <message>
      <source>Navigation error: No valid global position estimate</source>
      <translation type="unfinished">Navigation error: No valid global position estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10011251/description</name>
    <message>
      <source>The available positioning data is not sufficient to execute the selected mode.</source>
      <translation type="unfinished">The available positioning data is not sufficient to execute the selected mode.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10198977/message</name>
    <message>
      <source>GPS PDOP too high</source>
      <translation>Занадто висока GPS PDOP (погіршення точності позиції)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10198977/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10450063/message</name>
    <message>
      <source>No valid attitude estimate</source>
      <translation>Не визначено належного стану орієнтації</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10450063/description</name>
    <message>
      <source>Wait until the estimator initialized</source>
      <translation>Дочекайтесь ініціалізації оцінника</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1049276/message</name>
    <message>
      <source>GPS Horizontal Position Error too high</source>
      <translation>Занадто велика помилка GPS горизонтального положення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1049276/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10678671/message</name>
    <message>
      <source>GPS Speed Accuracy too low</source>
      <translation>Занадто низька точність GPS швидкості</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10678671/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10960133/message</name>
    <message>
      <source>Position estimate has low accuracy</source>
      <translation type="unfinished">Position estimate has low accuracy</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10960133/description</name>
    <message>
      <source>Local position estimate valid but has low accuracy. Warn user.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_POS_LOW_EPH&lt;/param&gt; and &lt;param&gt;COM_POS_LOW_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation type="unfinished">Local position estimate valid but has low accuracy. Warn user.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_POS_LOW_EPH&lt;/param&gt; and &lt;param&gt;COM_POS_LOW_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10996333/message</name>
    <message>
      <source>Missing FMU SD Card</source>
      <translation>Відсутня FMU SD картка</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10996333/description</name>
    <message>
      <source>Insert an SD Card to the autopilot and reboot the system.</source>
      <translation type="unfinished">Insert an SD Card to the autopilot and reboot the system.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11047904/message</name>
    <message>
      <source>Arming check summary event</source>
      <translation>Підсумок події перевірки активації</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11344647/message</name>
    <message>
      <source>Emergency battery level</source>
      <translation type="unfinished">Emergency battery level</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11344647/description</name>
    <message>
      <source>The lowest battery state of charge is below the emergency threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_EMERGEN_THR&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">The lowest battery state of charge is below the emergency threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_EMERGEN_THR&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11413600/message</name>
    <message>
      <source>Wind speed is above limit ({3:.1m/s})</source>
      <translation>Швидкість вітру перевищує норму ({3:.1м/с})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11413600/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_WIND_MAX&lt;/param&gt; and &lt;param&gt;COM_WIND_MAX_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_WIND_MAX&lt;/param&gt; та &lt;param&gt;COM_WIND_MAX_ACT&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11464574/message</name>
    <message>
      <source>No offboard signal</source>
      <translation type="unfinished">No offboard signal</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11464574/description</name>
    <message>
      <source>The offboard component is not sending recent setpoints.</source>
      <translation type="unfinished">The offboard component is not sending recent setpoints.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11497430/message</name>
    <message>
      <source>GPS Vertical Position Drift too high</source>
      <translation>Занадто високий дріфт GPS положення по вертикалі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11497430/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12276004/message</name>
    <message>
      <source>Global position estimate required</source>
      <translation type="unfinished">Global position estimate required</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12276004/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; parameter.
&lt;/profile&gt; The available positioning data is not sufficient to determine the vehicle's global position.</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; parameter.
&lt;/profile&gt; The available positioning data is not sufficient to determine the vehicle's global position.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12369553/message</name>
    <message>
      <source>GPS fix too low</source>
      <translation>Занадто низька точність GPS даних</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12369553/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/124285/message</name>
    <message>
      <source>Geofence RTL requires valid home</source>
      <translation>Гео-огорожа RTL(точки повернення до зльоту) потребує належної домашньої точки)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/124285/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;GF_ACTION&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12689900/message</name>
    <message>
      <source>Navigation error: No valid altitude estimate</source>
      <translation type="unfinished">Navigation error: No valid altitude estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12689900/description</name>
    <message>
      <source>The available positioning data is not sufficient to execute the selected mode.</source>
      <translation type="unfinished">The available positioning data is not sufficient to execute the selected mode.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12712246/message</name>
    <message>
      <source>Offboard requires local velocity</source>
      <translation type="unfinished">Offboard requires local velocity</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12712246/description</name>
    <message>
      <source>Offboard velocity control requires a valid local velocity estimate.</source>
      <translation type="unfinished">Offboard velocity control requires a valid local velocity estimate.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12754954/message</name>
    <message>
      <source>Flight termination active</source>
      <translation>Активне завершення польоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12780289/message</name>
    <message>
      <source>GPS jamming detected</source>
      <translation type="unfinished">GPS jamming detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12805643/message</name>
    <message>
      <source>Mission cannot be completed</source>
      <translation>Місія не може бути завершеною</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13094458/message</name>
    <message>
      <source>Not enough GPS Satellites</source>
      <translation>Не достатньо GPS супутників</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13094458/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1326449/message</name>
    <message>
      <source>Gyro {3} uncalibrated</source>
      <translation>Гіро {3} не відкалібровано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13426421/message</name>
    <message>
      <source>No heading reference</source>
      <translation type="unfinished">No heading reference</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13426421/description</name>
    <message>
      <source>No heading source has aligned the EKF yaw</source>
      <translation type="unfinished">No heading source has aligned the EKF yaw</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13528143/message</name>
    <message>
      <source>Vehicle is in transition state</source>
      <translation>Апарат в перехідному стані</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13679014/message</name>
    <message>
      <source>Offboard requires local position</source>
      <translation type="unfinished">Offboard requires local position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13679014/description</name>
    <message>
      <source>Offboard position control requires a valid local position estimate.</source>
      <translation type="unfinished">Offboard position control requires a valid local position estimate.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13835193/message</name>
    <message>
      <source>Navigation error: No valid position estimate</source>
      <translation type="unfinished">Navigation error: No valid position estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13835193/description</name>
    <message>
      <source>The available positioning data is not sufficient to execute the selected mode.</source>
      <translation type="unfinished">The available positioning data is not sufficient to execute the selected mode.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13923616/message</name>
    <message>
      <source>Geofence violation: exceeding maximum altitude above Home</source>
      <translation>Порушення гео-огорожі: перевищено максимальну висоту над домашньою точкою</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13923616/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; and &lt;param&gt;GF_MAX_VER_DIST&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;GF_ACTION&lt;/param&gt; та &lt;param&gt;GF_MAX_VER_DIST&lt;/param&gt; параметри.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14200647/message</name>
    <message>
      <source>Vehicle is not in multicopter mode</source>
      <translation>Апарат не знаходиться у режимі мультикоптера</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14200647/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_VTOLARMING&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;CBRK_VTOLARMING&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/143019/message</name>
    <message>
      <source>Geofence violation: approaching or outside geofence</source>
      <translation>Порушення гео-огорожі: наближення або вихід за межі гео-огорожі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/143019/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;GF_ACTION&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14644618/message</name>
    <message>
      <source>Maximum flight time reached</source>
      <translation>Досягнуто максимального часу польоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14644618/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_FLT_TIME_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_FLT_TIME_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14748737/message</name>
    <message>
      <source>Mode is not registered</source>
      <translation>Режим не зареєстровано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14748737/description</name>
    <message>
      <source>The application running the mode is not started.</source>
      <translation>Не запущено застосунок, який забезпечує роботу режиму.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14995448/message</name>
    <message>
      <source>GPS signal jammed</source>
      <translation type="unfinished">GPS signal jammed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14995448/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/15180799/message</name>
    <message>
      <source>VTOL fixed-wing system failure detected. Verify reason for failure, and reboot the vehicle once confirmed safe</source>
      <translation>Виявлено помилку системи вертикального зльоту/посадки фіксованого крила. Перевірте причину помилки та перезавантажте апарат, коли підтверджено безпеку</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/15713375/message</name>
    <message>
      <source>Strong magnetic interference</source>
      <translation>Потужне магнітне втручання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/15713375/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Measured strength: {3:.3}, expected: {4:.3} ± &lt;param&gt;EKF2_MAG_CHK_STR&lt;/param&gt; Measured inclination: {5:.3}, expected: {6:.3} ± &lt;param&gt;EKF2_MAG_CHK_INC&lt;/param&gt; This check can be configured via &lt;param&gt;COM_ARM_MAG_STR&lt;/param&gt; and &lt;param&gt;EKF2_MAG_CHECK&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Вимерена потужність: {3:.3}, очікувана: {4:.3} ± &lt;param&gt;EKF2_MAG_CHK_STR&lt;/param&gt; Вимерений нахил: {5:.3}, очікуваний: {6:.3} ± &lt;param&gt;EKF2_MAG_CHK_INC&lt;/param&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_MAG_STR&lt;/param&gt; and &lt;param&gt;EKF2_MAG_CHECK&lt;/param&gt; параметри.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16158540/message</name>
    <message>
      <source>Landing gear switch set in UP position</source>
      <translation>Блок приземлення переведено у положення UP</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16265915/message</name>
    <message>
      <source>Offboard requires attitude estimate</source>
      <translation type="unfinished">Offboard requires attitude estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16265915/description</name>
    <message>
      <source>Offboard acceleration and attitude control require a valid attitude estimate.</source>
      <translation type="unfinished">Offboard acceleration and attitude control require a valid attitude estimate.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16642797/message</name>
    <message>
      <source>Heading estimate invalid</source>
      <translation type="unfinished">Heading estimate invalid</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16642797/description</name>
    <message>
      <source>Recalibrate compass or perform manual heading reset.</source>
      <translation type="unfinished">Recalibrate compass or perform manual heading reset.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16716537/message</name>
    <message>
      <source>Compass {3} uncalibrated</source>
      <translation>Компас {3} не відкалібровано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16745468/message</name>
    <message>
      <source>Attitude failure detected</source>
      <translation>Помилка визначення стану орієнтації</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16745468/description</name>
    <message>
      <source>The vehicle exceeded the maximum configured pitch angle.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_FAIL_P&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Апарат перевищив максимально встановлений кут тангажу.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;FD_FAIL_P&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1802995/message</name>
    <message>
      <source>Airspeed too high</source>
      <translation>Швидкість польоту занадто висока</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1802995/description</name>
    <message>
      <source>Current airspeed reading too high. Check if wind is below maximum airspeed and redo airspeed calibration if the measured airspeed does not correspond to wind conditions.

&lt;profile name="dev"&gt; Measured: {3:.1m/s}, limit: {4:.1m/s}.

This check can be configured via &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Занадто висока поточна зчитувана швидкість польоту. Перевірте чи швидкість вітру нижче за максимальну швидкість польоту та повторіть калібрування швидкості польоту якщо виміряна швидкість польоту не відповідає умовам вітру.

&lt;profile name="dev"&gt; Виміряно: {3:.1m/s}, ліміт: {4:.1m/s}.

Ця перевірка може бути налаштована через &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1871713/message</name>
    <message>
      <source>Mode not suitable for arming</source>
      <translation>Режим не підходить для активації</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1871713/description</name>
    <message>
      <source>Switch to another mode first.</source>
      <translation>Спочатку перейдіть на інший режим.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1917030/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: TRIM greater than MAX ({4} greater than {5})</source>
      <translation>Калібрування пульта(RC) для {3} є невдалим: TRIM більше за MAX ({4} більше за {5})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1917030/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation>Перекалібруйте пульт(RC).</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2088119/message</name>
    <message>
      <source>Poor GPS Quality</source>
      <translation>Низька якість GPS</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2228586/message</name>
    <message>
      <source>Remaining flight time low</source>
      <translation>Низький залишок політного часу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2229864/message</name>
    <message>
      <source>Power redundancy not met</source>
      <translation>Надлишок живлення нижче норми</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2229864/description</name>
    <message>
      <source>Available power modules: {3}. Required power modules: {4}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_POWER_COUNT&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Доступні модулі живлення: {3}. Потрібні модулі живлення: {4}.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_POWER_COUNT&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2481841/message</name>
    <message>
      <source>Gyro {3} inconsistent</source>
      <translation>Гіроскоп {3} нестабільний</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2481841/description</name>
    <message>
      <source>Check the calibration.

Inconsistency value: {4}. Configured Threshold: {5}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_IMU_GYR&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Перевірте калібрування.

Нестабільне значення: {4}. Налаштований поріг: {5}.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_IMU_GYR&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2627595/message</name>
    <message>
      <source>Critical battery</source>
      <translation type="unfinished">Critical battery</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2627595/description</name>
    <message>
      <source>The lowest battery state of charge is below the critical threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_CRIT_THR&lt;/param&gt; and from when to disalow arming with &lt;param&gt;COM_ARM_BAT_MIN&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">The lowest battery state of charge is below the critical threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_CRIT_THR&lt;/param&gt; and from when to disalow arming with &lt;param&gt;COM_ARM_BAT_MIN&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/276785/message</name>
    <message>
      <source>Press safety button first</source>
      <translation>Натисніть спочатку кнопку запобіжника</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/276785/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_IO_SAFETY&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;CBRK_IO_SAFETY&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3061044/message</name>
    <message>
      <source>Accel {3} inconsistent</source>
      <translation>Прискорення {3} нестабільне</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3061044/description</name>
    <message>
      <source>Check the calibration.

Inconsistency value: {4}. Configured Threshold: {5}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_IMU_ACC&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Перевірте калібрування.

Нестабільне значення: {4}. Налаштований поріг: {5}.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_IMU_ACC&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3603209/message</name>
    <message>
      <source>Stopping compass use</source>
      <translation>Припинення використання компасу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3603209/description</name>
    <message>
      <source>Land and calibrate the compass.</source>
      <translation>Приземлитися та відкалібрувати компас.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3613628/message</name>
    <message>
      <source>High Accelerometer Bias</source>
      <translation>Велике відхилення акселерометра</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3613628/description</name>
    <message>
      <source>An accelerometer recalibration might help.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

This check can be configured via &lt;param&gt;EKF2_ABL_LIM&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Перекалібрування акселерометра може допомогти.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

Ця перевірка може бути налаштована через &lt;param&gt;EKF2_ABL_LIM&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/377561/message</name>
    <message>
      <source>No valid mission available</source>
      <translation>Немає дійсної місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/377561/description</name>
    <message>
      <source>Upload a mission first.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_MIS_REQ&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Спочатку завантажте місію.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_MIS_REQ&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4065583/message</name>
    <message>
      <source>Geofence violation: exceeding maximum distance to Home</source>
      <translation>Порушення гео-огорожі: перевищено максимальну дистанцію до точки повернення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4065583/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; and &lt;param&gt;GF_MAX_HOR_DIST&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;GF_ACTION&lt;/param&gt; та &lt;param&gt;GF_MAX_HOR_DIST&lt;/param&gt; параметри.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4261821/message</name>
    <message>
      <source>Failure triggered by external system</source>
      <translation>Помилка викликана зовнішньою системою</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4261821/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_EXT_ATS_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;FD_EXT_ATS_EN&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/453929/message</name>
    <message>
      <source>No manual control input</source>
      <translation>Немає ручного контролю введення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/453929/description</name>
    <message>
      <source>Connect and enable stick input or use autonomous mode.
&lt;profile name="dev"&gt; Sticks can be enabled via &lt;param&gt;COM_RC_IN_MODE&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Під'єднайте та активуйте керування стіками або використовуйте автономний режим.
&lt;profile name="dev"&gt; Стіки можуть бути активовані через &lt;param&gt;COM_RC_IN_MODE&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4549029/message</name>
    <message>
      <source>Altitude failure detected</source>
      <translation>Виявлено помилку висоти</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4554738/message</name>
    <message>
      <source>No rally point configured</source>
      <translation type="unfinished">No rally point configured</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4554738/description</name>
    <message>
      <source>No rally point is configured. Return will fall back to the current position when RTL is triggered. Upload at least one rally point, or change &lt;param&gt;RTL_TYPE&lt;/param&gt; to silence this warning.

&lt;profile name="dev"&gt; This warning is active when RTL_TYPE is set to 5 (safe points only).
&lt;/profile&gt;</source>
      <translation type="unfinished">No rally point is configured. Return will fall back to the current position when RTL is triggered. Upload at least one rally point, or change &lt;param&gt;RTL_TYPE&lt;/param&gt; to silence this warning.

&lt;profile name="dev"&gt; This warning is active when RTL_TYPE is set to 5 (safe points only).
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4975227/message</name>
    <message>
      <source>GPS Horizontal Speed Drift too high</source>
      <translation>Занадто великий горизонтальний швидкісний GPS дріфт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4975227/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5049764/message</name>
    <message>
      <source>Low battery</source>
      <translation>Низький заряд батареї</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5049764/description</name>
    <message>
      <source>The lowest battery state of charge is below the low threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_LOW_THR&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">The lowest battery state of charge is below the low threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_LOW_THR&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/516062/message</name>
    <message>
      <source>GPS Vertical Position Error too high</source>
      <translation>Занадто велика помилка GPS вертикального позиціювання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/516062/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5273740/message</name>
    <message>
      <source>Compass inconsistent by {3} degrees</source>
      <translation>Похибка компасу {3} градусів</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5273740/description</name>
    <message>
      <source>Check the compass orientations and recalibrate.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_MAG_ANG&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Перевірте орієнтацію компасу та перекалібруйте.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_MAG_ANG&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5444856/message</name>
    <message>
      <source>Accelerometer {3} uncalibrated</source>
      <translation>Акселерометр {3} не відкалібровано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5704353/message</name>
    <message>
      <source>Arm authorization denied</source>
      <translation>Авторизацію активації відхилено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5717196/message</name>
    <message>
      <source>GPS Horizontal Position Drift too high</source>
      <translation>Занадто великий дріфт горизонтальної GPS позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5717196/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5943233/message</name>
    <message>
      <source>Found {3} compass (required: {4})</source>
      <translation>Знайдено {3} компас (необхідно: {4})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5943233/description</name>
    <message>
      <source>Make sure all required sensors are working, enabled and calibrated.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_MAG&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Переконайтеся що усі необхідні сенсори працюють, їх увімкнено та прокалібровано.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;SYS_HAS_MAG&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6054338/message</name>
    <message>
      <source>Waiting for estimator to initialize</source>
      <translation>Очікування ініціалізації оцінювача</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6258044/message</name>
    <message>
      <source>Estimator fault due to Compass {3}</source>
      <translation>Помилка оцінювача через компас {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6258044/description</name>
    <message>
      <source>Recalibrate the compass and check the orientation.</source>
      <translation>Перекалібруйте компас та перевірте орієнтування.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6491364/message</name>
    <message>
      <source>Home position required</source>
      <translation>Необхідна точка зльоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6491364/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6558257/message</name>
    <message>
      <source>GPS Vertical Speed Drift too high</source>
      <translation>Занадто великий вертикальний швидкісний GPS дріфт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6558257/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6801787/message</name>
    <message>
      <source>No connection to the ground control station</source>
      <translation>Немає з'єднання з наземною станцією</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6801787/description</name>
    <message>
      <source>To arm, at least a data link or RC must be present.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;NAV_DLL_ACT&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">To arm, at least a data link or RC must be present.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;NAV_DLL_ACT&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6979701/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: MIN less than {4}</source>
      <translation>Калібрування пульта(RC) для каналу {3} є невдалим: MIN менше ніж {4}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6979701/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation>Перекалібрувати пульт(RC).</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7662152/message</name>
    <message>
      <source>USB connected</source>
      <translation>USB під'єднано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7662152/description</name>
    <message>
      <source>Flying with USB is not safe. Disconnect it and reboot the FMU.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_USB_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Літати з USB небезпечно. Від'єднайте це та перезавантажте FMU (польотний контролер).

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;CBRK_USB_CHK&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7847312/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: MAX greater than {4}</source>
      <translation>Калібрування пульта(RC) для каналу {3} є невдалим: MAX більше ніж {4}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7847312/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation>Перекалібрувати пульт(RC).</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7884377/message</name>
    <message>
      <source>RTL switch engaged</source>
      <translation>Перемикач RTL (повернення на точку злету) задіяно</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/79408/message</name>
    <message>
      <source>Home position not set</source>
      <translation>Перемикач RTL (повернення на точку злету) задіяно</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7959667/message</name>
    <message>
      <source>Vehicle is in safety configuration</source>
      <translation>Апарат у безпечному режимі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7959667/description</name>
    <message>
      <source>Vehicle is in safety configuration and denies arming.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARMABLE&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Апарат у безпечному режимі та не сприймає активацію.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARMABLE&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/810921/message</name>
    <message>
      <source>Waypoint above maximum height</source>
      <translation type="unfinished">Waypoint above maximum height</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8495477/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: TRIM less than MIN ({4} less than {5})</source>
      <translation>Калібрування пульта(RC) для каналу {3} є невдалим: TRIM менше ніж MIN ({4} менше ніж {5})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8495477/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation>Перекалібрувати пульт(RC).</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8538897/message</name>
    <message>
      <source>Attitude failure detected</source>
      <translation>Виявлено помилку стану орієнтації</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8538897/description</name>
    <message>
      <source>The vehicle exceeded the maximum configured roll angle.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_FAIL_R&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Апарат перевищив налаштований максимум кута крену.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;FD_FAIL_R&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8713942/message</name>
    <message>
      <source>GPS signal spoofed</source>
      <translation type="unfinished">GPS signal spoofed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8713942/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8902208/message</name>
    <message>
      <source>Horizontal velocity unstable</source>
      <translation>Нестабільна горизонтальна швидкість</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9077977/message</name>
    <message>
      <source>Kill switch engaged</source>
      <translation>Знешкодити залучений перемикач</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9134139/message</name>
    <message>
      <source>Traffic avoidance system missing</source>
      <translation type="unfinished">Traffic avoidance system missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9134139/description</name>
    <message>
      <source>Traffic avoidance system (ADSB/FLARM) failed to report. Make sure it is setup and connected properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_TRAFF&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Traffic avoidance system (ADSB/FLARM) failed to report. Make sure it is setup and connected properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_TRAFF&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9171208/message</name>
    <message>
      <source>Vertical velocity unstable</source>
      <translation>Нестабільна вертикальна висота</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9307221/message</name>
    <message>
      <source>High Gyro Bias</source>
      <translation>Велике відхилення гіроскопа</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9307221/description</name>
    <message>
      <source>A Gyro recalibration might help.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

This check can be configured via &lt;param&gt;EKF2_ABL_GYRLIM&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Перекалібрування гіроскопа може допомогти.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

Ця перевірка може бути налаштована через &lt;param&gt;EKF2_ABL_GYRLIM&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9608226/message</name>
    <message>
      <source>Estimator not using GPS</source>
      <translation>Оцінювач не використовує GPS</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9634798/message</name>
    <message>
      <source>Height estimate not stable</source>
      <translation>Вимірювання висоти не стабільне</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9643369/message</name>
    <message>
      <source>Angular velocity not valid</source>
      <translation>Неприпустима кутова швидкість</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9643369/description</name>
    <message>
      <source>Make sure the gyroscope is providing valid data.</source>
      <translation>Переконайтеся що гіроскоп надає належні дані.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9697819/message</name>
    <message>
      <source>Horizontal position unstable</source>
      <translation type="unfinished">Horizontal position unstable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9815168/message</name>
    <message>
      <source>Mode is unresponsive</source>
      <translation>Режим не відповідає</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9815168/description</name>
    <message>
      <source>The application running the mode might have crashed or the CPU load is too high.</source>
      <translation>Поточний режим додатка ймовірно дав збій або навантаження центрального процесора(CPU) є надто великим.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9965819/message</name>
    <message>
      <source>GNSS heading not reliable</source>
      <translation>GNSS напрямок не є надійним</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9965819/description</name>
    <message>
      <source>Land now</source>
      <translation>Приземлитися зараз</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10044444/message</name>
    <message>
      <source>Error loading settings</source>
      <translation>Помилка завантаження налаштувань</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10072599/message</name>
    <message>
      <source>Calibration: Disabling RC input</source>
      <translation>Калібрування: вимкнення входу пульта(RC)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1013050/message</name>
    <message>
      <source>Calibration denied: not supported in SIH mode</source>
      <translation type="unfinished">Calibration denied: not supported in SIH mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10155243/message</name>
    <message>
      <source>Unsupported base mode</source>
      <translation type="unfinished">Unsupported base mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10162376/message</name>
    <message>
      <source>Mission land item could not be read</source>
      <translation>Елемент приземлення місії не може бути прочитаний</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10229254/message</name>
    <message>
      <source>RTL Mission Land: climb to {1m_v}</source>
      <translation>RTL(повернення до точки запуску) місії приземлення: піднятися до {1m_v}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10236960/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}</source>
      <translation>Попередження про трафік - ICAO(міжнародна організація цивільної авіації) адреса {1}! Дистанція Розділення {2}, Напрямок {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10236960/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation>- ICAO Адреса: {1}
- Дистанція Розділення Трафіку: {2m}
- Напрямок: {3} degrees</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10250020/message</name>
    <message>
      <source>CA_SV_CS{1}_TRIM ({2}) is reset to 0 as PWM CENTER is used</source>
      <translation type="unfinished">CA_SV_CS{1}_TRIM ({2}) is reset to 0 as PWM CENTER is used</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10250020/description</name>
    <message>
      <source>Display warning in GCS when TRIM settings were present and now CENTER are set.</source>
      <translation type="unfinished">Display warning in GCS when TRIM settings were present and now CENTER are set.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10384464/message</name>
    <message>
      <source>Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</source>
      <translation type="unfinished">Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10452355/message</name>
    <message>
      <source>Takeoff airspeed reached, climbout</source>
      <translation>Швидкості злету досягнуто, набираємо висоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1047676/message</name>
    <message>
      <source>Enabling transmitting with IRIDIUM mavlink on instance {1} by command</source>
      <translation>Вмикання передавання через IRIDIUM mavlink наприклад {1} по команді</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10493596/message</name>
    <message>
      <source>Airspeed sensor failure detected. Return to launch (RTL) is advised</source>
      <translation>Виявлено помилку сенсора швидкості польоту. Рекомендовано повернення на точку запуску (RTL)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10503063/message</name>
    <message>
      <source>Switching to mode '{2}' is currently not possible</source>
      <translation>Перемикання у режим '{2}' на цей момент неможливе</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10600202/message</name>
    <message>
      <source>Arming denied: throttle not in safe position</source>
      <translation type="unfinished">Arming denied: throttle not in safe position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10658115/message</name>
    <message>
      <source>SET_POSITION_TARGET_GLOBAL_INT: FORCE is not supported</source>
      <translation>SET_POSITION_TARGET_GLOBAL_INT: FORCE не підтримується</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10664053/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, returning home</source>
      <translation>Попередження про трафік - ICAO Адреса {1}! Дистанція Розділення {2}, Напрямок {3}, вертання на точку повернення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10664053/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation>- ICAO Адреса: {1}
- Дистанція Розділення Трафіку: {2m}
- Напрямок: {3} градусів</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10716939/message</name>
    <message>
      <source>Onboard controller regained</source>
      <translation>Вбудований контролер відновлено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10794072/message</name>
    <message>
      <source>Connection to ground control station lost</source>
      <translation>З'єднання зі станцією наземного контролю втрачено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10834203/message</name>
    <message>
      <source>Enabling transmitting with IRIDIUM mavlink on instance {1}</source>
      <translation>Вмикання передавання через IRIDIUM mavlink наприклад {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10962739/message</name>
    <message>
      <source>SET_POSITION_TARGET_GLOBAL_INT invalid coordinate frame {1}</source>
      <translation>SET_POSITION_TARGET_GLOBAL_INT неприйнятна система координат {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10973461/message</name>
    <message>
      <source>Geofence invalid, doesn't contain Home position</source>
      <translation>Неприйнятна гео-огорожа, не містить точки повернення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11085221/message</name>
    <message>
      <source>Mission: unable to write to storage</source>
      <translation>Місія: неможливо зробити запис у сховище</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11123101/message</name>
    <message>
      <source>Connection to mission computer lost</source>
      <translation>Втрачено з'єднання з комп'ютером місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1119664/message</name>
    <message>
      <source>Invalid configuration: FW_AIRSPD_STALL higher FW_AIRSPD_MIN</source>
      <translation>Недійсний конфігуратор: FW_AIRSPD_STALL вище за FW_AIRSPD_MIN</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1119664/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_STALL&lt;/param&gt;: {2:.1}</source>
      <translation>- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_STALL&lt;/param&gt;: {2:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11290563/message</name>
    <message>
      <source>Kill engaged</source>
      <translation>Знищення залучено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11331989/message</name>
    <message>
      <source>Manual control lost: switching to Hold</source>
      <translation type="unfinished">Manual control lost: switching to Hold</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11521721/message</name>
    <message>
      <source>Mission rejected: Mission contains VTOL items but vehicle is not a VTOL</source>
      <translation>Місію відхилено: Місія містить елементи VTOL (вертикальний зліт/посадка) але апарат не є VTOL</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11552065/message</name>
    <message>
      <source>SET_POSITION_TARGET_LOCAL_NED: coordinate frame {1} unsupported</source>
      <translation>SET_POSITION_TARGET_LOCAL_NED: система координат {1} не підтримується</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11572261/message</name>
    <message>
      <source>Reduce the glide slope, lower the entrance altitude {1} meters, or increase the landing approach distance {2} meters</source>
      <translation>Зменшити нахил глісади, знизити вхідну висоту {1} метрів, або збільшити відстань наближення до приземлення {2} метрів</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11606074/message</name>
    <message>
      <source>Launch detected: enable motors (no motor delay)</source>
      <translation>Виявлено запуск: увімкніть мотори (без затримки моторів)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11664376/message</name>
    <message>
      <source>Mission: Unable to read from storage</source>
      <translation>Місія: Неможливо зчитати зі сховища</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11664376/description</name>
    <message>
      <source>Mission type: {1}</source>
      <translation>Тип місії: {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11724756/message</name>
    <message>
      <source>Waypoint {1} could not be read from storage</source>
      <translation>Точка маршруту {1} не може бути зчитана зі сховища</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11926110/message</name>
    <message>
      <source>Calibration denied: not supported in SIH mode</source>
      <translation type="unfinished">Calibration denied: not supported in SIH mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11985219/message</name>
    <message>
      <source>Holding at {1:.0m_v} above landing waypoint</source>
      <translation>Утримання на {1:.0m_v} над точкою приземлення на маршруті</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1203183/message</name>
    <message>
      <source>logging: opening log file {1}-{2}-{3}/{4}_{5}_{6}.ulg</source>
      <translation>ведення журналу записів: відкриття файлу журнала записів {1}-{2}-{3}/{4}_{5}_{6}.ulg</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12140426/message</name>
    <message>
      <source>EKF2_MAG_TYPE invalid, resetting to default</source>
      <translation>EKF2_MAG_TYPE недійсний, перезавантаження до налаштувань за замовченням</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12140426/description</name>
    <message>
      <source>&lt;param&gt;EKF2_MAG_TYPE&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;EKF2_MAG_TYPE&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12208749/message</name>
    <message>
      <source>Mission rejected: takeoff altitude too low! Minimum: {1:.1m_v}</source>
      <translation>Місію відхилено: висота зльоту занадто мала! Мінімум: {1:.1m_v}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12216659/message</name>
    <message>
      <source>Low battery level, return advised</source>
      <translation>Низький заряд батареї, рекомендовано повернення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12221094/message</name>
    <message>
      <source>Landing target: unsupported coordinate frame {1}</source>
      <translation>Ціль приземлення: непідтримувана система координат {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12224414/message</name>
    <message>
      <source>Mission rejected: Takeoff or Landing item missing</source>
      <translation>Місію відхилено: елемент Зльоту або Приземлення відсутній</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/122461/message</name>
    <message>
      <source>Landing aborted: terrain measurement not found</source>
      <translation>Приземлення скасовано: не знайдено розмірів ландшафту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12306507/message</name>
    <message>
      <source>Target altitude higher than max HAGL</source>
      <translation type="unfinished">Target altitude higher than max HAGL</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12320347/message</name>
    <message>
      <source>Primary airspeed index bigger than number connected sensors, taking last sensor</source>
      <translation>Початковий індекс швидкості польоту більше за кількість підключених сенсорів, візьміть останній сенсор</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12464476/message</name>
    <message>
      <source>Ready for throw launch</source>
      <translation>Готовий до підкидного запуску</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12472677/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_SPEED_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_SPEED_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12499622/message</name>
    <message>
      <source>Mission: Unable to write to storage</source>
      <translation>Місія: неможливо зробити запис у сховище</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12500025/message</name>
    <message>
      <source>Mission: Unable to write to storage</source>
      <translation>Місія: неможливо зробити запис у сховище</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12621639/message</name>
    <message>
      <source>Remote ID system lost</source>
      <translation type="unfinished">Remote ID system lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12768213/message</name>
    <message>
      <source>Mission rejected: more than one land start commands</source>
      <translation>Місію відхилено: більше однієї команди про старт приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12770418/message</name>
    <message>
      <source>Failsafe activated: Autopilot disengaged, switching to {2}</source>
      <translation type="unfinished">Failsafe activated: Autopilot disengaged, switching to {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12770418/description</name>
    <message>
      <source>Failsafe actions that disengage the autopilot (remove position control)</source>
      <translation type="unfinished">Failsafe actions that disengage the autopilot (remove position control)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12815955/message</name>
    <message>
      <source>SET_POSITION_TARGET_LOCAL_NED: FORCE is not supported</source>
      <translation>SET_POSITION_TARGET_LOCAL_NED: FORCE не підтримується</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12894058/message</name>
    <message>
      <source>{1} sensor #{2} failure: {3}</source>
      <translation>{1} сенсор #{2} невдача: {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12894058/description</name>
    <message>
      <source>Land immediately and check the system.</source>
      <translation>Терміново приземляйтеся та перевірте систему.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12957883/message</name>
    <message>
      <source>Start descending</source>
      <translation>Старт зниження</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12987489/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_P</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_P</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13168253/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RA_WHEEL_BASE</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RA_WHEEL_BASE</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13277401/message</name>
    <message>
      <source>Failsafe warning:</source>
      <translation>Попередження безаварійності:</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13277401/description</name>
    <message>
      <source>No action is triggered.</source>
      <translation>Не викликано ніякої дії.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/133277/message</name>
    <message>
      <source>Arming denied: Resolve system health failures first</source>
      <translation>Активацію відхилено: Спочатку вирішіть неполадки у системі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13378512/message</name>
    <message>
      <source>Distance between waypoint and gate too close: {1:.3m} (minimum: {2:.3m})</source>
      <translation>Занадто мала відстань між точкою маршруту та пунктом: {1:.3m}(minimum: {2:.3m})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13440627/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_MAX_THR_SPEED</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_MAX_THR_SPEED</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13471314/message</name>
    <message>
      <source>Quad-chute triggered due to loss of altitude during transition</source>
      <translation>Quad-chute спрацював через втрату висоти під час переходу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13495236/message</name>
    <message>
      <source>Reposition is outside geofence</source>
      <translation>Перепозиціонування за межами гео-огорожі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1351736/message</name>
    <message>
      <source>Traffic avoidance system regained</source>
      <translation type="unfinished">Traffic avoidance system regained</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13568553/message</name>
    <message>
      <source>New mission waypoint sequence out of bounds</source>
      <translation>Нова послідовність точок маршруту поза межами зони</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13612093/message</name>
    <message>
      <source>Traffic avoidance system lost</source>
      <translation type="unfinished">Traffic avoidance system lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1369685/message</name>
    <message>
      <source>Takeoff on runway</source>
      <translation>Зліт на злітній смузі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13704694/message</name>
    <message>
      <source>{4}: switching to {2} in {3} seconds</source>
      <translation>{4}: перемкнутися на {2} через {3} секунди</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13944665/message</name>
    <message>
      <source>Transition to hover mode and descend</source>
      <translation>Перехід до режиму зависання та спускання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13956202/message</name>
    <message>
      <source>Mission rejected: invalid land start</source>
      <translation>Місію відхилено: неприпустимий старт з землі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14080694/message</name>
    <message>
      <source>Descent speed has been constrained by max speed</source>
      <translation>Швидкість зниження обмежена максимальною швидкістю</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14080694/description</name>
    <message>
      <source>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1410140/message</name>
    <message>
      <source>Quad-chute triggered due to external command</source>
      <translation>Quad-chute задіяно через зовнішню команду</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14117485/message</name>
    <message>
      <source>EKF2_DELAY_MAX increased to {2}ms, please reboot</source>
      <translation>EKF2_DELAY_MAX збільшено до {2}мс, будь ласка, перезавантажте</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14117485/description</name>
    <message>
      <source>EKF2_DELAY_MAX({1}ms) is too small compared to the maximum sensor delay ({2})</source>
      <translation>EKF2_DELAY_MAX({1}мс) занадто малий у порівнянні з максимальною затримкою датчика ({2})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14153224/message</name>
    <message>
      <source>Manual speed has been constrained by maximum speed</source>
      <translation>Ручна швидкість була обмежена максимальною швидкістю</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14153224/description</name>
    <message>
      <source>&lt;param&gt;MPC_VEL_MANUAL&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14234660/message</name>
    <message>
      <source>GCS connection regained</source>
      <translation>З'єднання GCS відновлено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14238006/message</name>
    <message>
      <source>RTL destination invalid, not updating</source>
      <translation type="unfinished">RTL destination invalid, not updating</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14440680/message</name>
    <message>
      <source>Mission sync timeout, aborting transfer</source>
      <translation type="unfinished">Mission sync timeout, aborting transfer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14443523/message</name>
    <message>
      <source>Launch detected: enable motors</source>
      <translation>Виявлено запуск: увімкнути двигуни</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14530735/message</name>
    <message>
      <source>Target relative: unsupported coordinate frame {1}</source>
      <translation type="unfinished">Target relative: unsupported coordinate frame {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14535820/message</name>
    <message>
      <source>Landing aborted: terrain estimate timed out</source>
      <translation>Приземлення скасовано: термін оцінювання ландшафту вичерпано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14581325/message</name>
    <message>
      <source>Maximum tilt limit has been constrained to a safe value</source>
      <translation>Максимальне ліміт нахилу обмежено до безпечного значення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14581325/description</name>
    <message>
      <source>&lt;param&gt;MPC_TILTMAX_AIR&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14605264/message</name>
    <message>
      <source>Failsafe activated: switching to {2}</source>
      <translation type="unfinished">Failsafe activated: switching to {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14699175/message</name>
    <message>
      <source>GNSS data fusion stopped</source>
      <translation>Поєднання GNSS даних зупинено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15098248/message</name>
    <message>
      <source>Disabling transmitting with IRIDIUM mavlink on instance {1}</source>
      <translation>Вимкнення передавання через IRIDIUM mavlink наприклад {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1525547/message</name>
    <message>
      <source>Landing aborted: unknown criterion</source>
      <translation>Приземлення перервано: невідомий критерій</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15283212/message</name>
    <message>
      <source>Mission download request ignored, already active</source>
      <translation>Запит на завантаження місій проігноровано, вже активний</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15292483/message</name>
    <message>
      <source>GNSS data fusion started</source>
      <translation>Поєднання GNSS даних розпочато</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15317431/message</name>
    <message>
      <source>Invalid configuration: Airspeed max \&lt; 5 m/s or min \&gt; 100 m/s</source>
      <translation>Некоректна конфігурація: максимальна повітряна швидкість \&lt; 5 м/с або мінімальна \&gt; 100 м/с</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15317431/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</source>
      <translation>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15373867/message</name>
    <message>
      <source>Launch detected: enablecontrol, waiting {1:.1}s until full throttle</source>
      <translation>Виявлено запуск: увімкнення контролю, очікування {1:.1}до повної тяги</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15438771/message</name>
    <message>
      <source>Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</source>
      <translation type="unfinished">Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15456613/message</name>
    <message>
      <source>Accel {1} clipping, not safe to fly!</source>
      <translation>Акселерометр {1} обрізає дані, летіти небезпечно!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15456613/description</name>
    <message>
      <source>Land now, and check the vehicle setup. Clipping can lead to fly-aways.</source>
      <translation>Приземліться зараз та перевірте налаштування апарату. Викривлення сигналу може призвести до задалеких відльотів.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15499150/message</name>
    <message>
      <source>Autotune axis selection not supported through Mission. Use FW_AT_AXES to set axes for fixed-wing vehicles</source>
      <translation type="unfinished">Autotune axis selection not supported through Mission. Use FW_AT_AXES to set axes for fixed-wing vehicles</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15536452/message</name>
    <message>
      <source>External mode is unresponsive, falling back to internal</source>
      <translation>Зовнішній режим не відповідає, повернення до внутрішнього</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15598001/message</name>
    <message>
      <source>Executing Mission</source>
      <translation>Виконання місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15603271/message</name>
    <message>
      <source>Dangerously low battery! Shutting system down</source>
      <translation>Небезпечно низький заряд батареї! Завершення роботи системи</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15624514/message</name>
    <message>
      <source>Wind speed above limit ({1:.1m/s}), landing advised</source>
      <translation>Швидкість вітру перевищує ліміт ({1:.1м/с}), рекомендуємо приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1569033/message</name>
    <message>
      <source>parameter_rc_channel_index out of bounds</source>
      <translation>parameter_rc_channel_index поза межами зони</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15869512/message</name>
    <message>
      <source>Quad-chute triggered due to transition timeout</source>
      <translation>Quad-chute викликано через тайм-аут переходу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15900704/message</name>
    <message>
      <source>Quad-chute triggered due to minimum altitude breach</source>
      <translation>Quad-chute викликано через перетин мінімальної висоти</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15909593/message</name>
    <message>
      <source>Cruise speed has been constrained by maximum speed</source>
      <translation>Крейсерська швидкість обмежена максимальною швидкістю</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15909593/description</name>
    <message>
      <source>&lt;param&gt;MPC_XY_CRUISE&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15936531/message</name>
    <message>
      <source>Target relative: unsupported coordinate frame {1} when the q_sensor is not filled</source>
      <translation type="unfinished">Target relative: unsupported coordinate frame {1} when the q_sensor is not filled</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1593841/message</name>
    <message>
      <source>Too much traffic! Showing all messages from now on</source>
      <translation>Забагато трафіку! Показуються всі повідомлення відтепер</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16017271/message</name>
    <message>
      <source>Disarmed by {1}</source>
      <translation>Охолощений за допомогою {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1604295/message</name>
    <message>
      <source>Terrain collision risk, descent is stopped</source>
      <translation type="unfinished">Terrain collision risk, descent is stopped</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16048801/message</name>
    <message>
      <source>Storage full: {1} MiB free</source>
      <translation type="unfinished">Storage full: {1} MiB free</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16048801/description</name>
    <message>
      <source>Free up space manually, or lower &lt;param&gt;SDLOG_ROTATE&lt;/param&gt;
(maximum disk usage percentage) so more headroom is kept free during writing.</source>
      <translation type="unfinished">Free up space manually, or lower &lt;param&gt;SDLOG_ROTATE&lt;/param&gt;
(maximum disk usage percentage) so more headroom is kept free during writing.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16090809/message</name>
    <message>
      <source>Geofence data invalid (code {1}), RTL will fly directly</source>
      <translation type="unfinished">Geofence data invalid (code {1}), RTL will fly directly</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16223078/message</name>
    <message>
      <source>Landing aborted by operator</source>
      <translation>Приземлення перервано оператором</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16329867/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_RATE_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_RATE_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16347639/message</name>
    <message>
      <source>Landing, flaring</source>
      <translation>Приземлення, спалювання (flaring)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16440365/message</name>
    <message>
      <source>ODOMETRY: unsupported estimator_type {1}</source>
      <translation>ОДОМЕТРІЯ: непідтримуваний estimator_type {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16509566/message</name>
    <message>
      <source>Mission rejected: Add Takeoff item or remove Landing</source>
      <translation>Місія відхилена: Додати елемент Зльоту або видалити Приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16558486/message</name>
    <message>
      <source>Disarmed, don't throw</source>
      <translation>Охолощений, не кидати</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16591495/message</name>
    <message>
      <source>Control high latency failed! Telemetry unavailable</source>
      <translation>Перевірка високої затримки не вдалася! Телеметрія недоступна</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16653157/message</name>
    <message>
      <source>Altitude change is outside geofence</source>
      <translation type="unfinished">Altitude change is outside geofence</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16663074/message</name>
    <message>
      <source>Mission rejected: takeoff is not the first waypoint item</source>
      <translation>Місію відхилено: зліт не є першою точкою маршруту елемента</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16682655/message</name>
    <message>
      <source>Kill disengaged</source>
      <translation>Ліквідувати незалучених</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16691824/message</name>
    <message>
      <source>Ignoring mission item, invalid item</source>
      <translation>Ігнорування предмет місії, неприпустимий предмет</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16725343/message</name>
    <message>
      <source>RTL: completed, loitering</source>
      <translation>RTL (повернення на точку злету): завершено, баражування</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1746622/message</name>
    <message>
      <source>Pilot took over using sticks</source>
      <translation>Пілот прийняв управління за допомогою стіків</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1801328/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, holding position</source>
      <translation>Попередження про трафік - ICAO Адреса {1}! Дистанція Розділення {2}, Напрямок {3}, утримання позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1801328/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation>- ICAO Адреса: {1}
- Дистанція Розділення Трафіку: {2m}
- Напрямок: {3} градусів</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/185258/message</name>
    <message>
      <source>RTL: land at destination</source>
      <translation>RTL: точка приземлення в місці призначення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1880909/message</name>
    <message>
      <source>Altitude change is outside geofence</source>
      <translation>Зміна висоти поза гео-огорожею</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1925166/message</name>
    <message>
      <source>Mission rejected: starts with landing</source>
      <translation>Місія відхилена: починається з посадки</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2020940/message</name>
    <message>
      <source>Roll command reduced due to uncertain velocity/wind estimates!</source>
      <translation>Команду крену скорочено через невизначені вимірювання швидкості польоту/швидкості вітру!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2066387/message</name>
    <message>
      <source>Arming denied: calibrating</source>
      <translation>Активацію відхилено: калібрування</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2087806/message</name>
    <message>
      <source>Orbit radius limit exceeded</source>
      <translation>Перевищено ліміт радіусу орбіти</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2308551/message</name>
    <message>
      <source>Low remaining flight time, return advised</source>
      <translation>Залишилося мало польотного часу, рекомендовано повернення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2321600/message</name>
    <message>
      <source>Already higher than takeoff altitude (not descending)</source>
      <translation>Вже вище, ніж висота зльоту (не знижується)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2440093/message</name>
    <message>
      <source>Unsupported ARM_DISARM param: {1:.3}</source>
      <translation>Непідтримуваний ARM_DISARM param: {1:.3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2474944/message</name>
    <message>
      <source>Critical battery level, land now</source>
      <translation>Критичний рівень батареї, приземліться зараз</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2566971/message</name>
    <message>
      <source>Disabling transmitting with IRIDIUM mavlink on instance {1} by command</source>
      <translation>Відключення передавання через IRIDIUM mavlink наприклад {1} по команді</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2659830/message</name>
    <message>
      <source>Waypoint index eceeds list capacity (maximum: {1})</source>
      <translation>Індекс точок маршруту перевищує місткість списку (максимум: {1})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2754873/message</name>
    <message>
      <source>Mission upload busy, ignoring MISSION_COUNT</source>
      <translation>Довантаження місії зайняте, ігнорується MISSION_COUNT</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2768743/message</name>
    <message>
      <source>Unsupported main mode</source>
      <translation type="unfinished">Unsupported main mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2769710/message</name>
    <message>
      <source>Mission rejected: Add Landing item or remove Takeoff</source>
      <translation>Місію відхилено: Додати предмет Приземлення або видалити Зліт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2831661/message</name>
    <message>
      <source>Geofence violation for waypoint {1}</source>
      <translation>Порушення геоогорожі для точки маршруту {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2842608/message</name>
    <message>
      <source>Mission rejected: Landing waypoint/pattern required</source>
      <translation>Місію відхилено: Необхідна точка маршруту/шаблон</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3038268/message</name>
    <message>
      <source>Received unknown mission type, abort</source>
      <translation>Отримано невідомий тип місії, переривання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3092229/message</name>
    <message>
      <source>Unsupported auto mode</source>
      <translation>Непідтримуваний автоматичний режим</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3198435/message</name>
    <message>
      <source>Mission rejected: the approach waypoint must be above the landing point</source>
      <translation>Місія відхилена: точка маршруту на підході повинна бути вище точки приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3237806/message</name>
    <message>
      <source>Landing, flaring</source>
      <translation>Приземлення, посадкове вирівнювання (flaring)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3321936/message</name>
    <message>
      <source>Waypoint index out of bounds (current {1} \&gt;= total {2})</source>
      <translation>Індекс точок vfhihene поза межами зони (поточне {1} \&gt;= всього {2})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3322590/message</name>
    <message>
      <source>Landing at current position</source>
      <translation/>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3327268/message</name>
    <message>
      <source>RTL: avoiding geofence</source>
      <translation type="unfinished">RTL: avoiding geofence</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3329221/message</name>
    <message>
      <source>Remote ID system regained</source>
      <translation type="unfinished">Remote ID system regained</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3357977/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RA_MAX_STR_ANG</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RA_MAX_STR_ANG</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3378258/message</name>
    <message>
      <source>Mission rejected: No home position, waypoint {1} uses relative altitude</source>
      <translation>Місія відхилена: немає точки зльоту, точка маршруту {1} використовує відносну висоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3383214/message</name>
    <message>
      <source>Mission rejected: dataman read failed at item {1} (dm_id={2})</source>
      <translation type="unfinished">Mission rejected: dataman read failed at item {1} (dm_id={2})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3390156/message</name>
    <message>
      <source>No valid mission available, loitering</source>
      <translation>Немає доступної місії, баражування</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3453129/message</name>
    <message>
      <source>Geofence requires a valid home position</source>
      <translation>Геоогорожа потребує дійсної точки зльоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/346311/message</name>
    <message>
      <source>Launch detection running</source>
      <translation>Детекція запуску працює</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3484900/message</name>
    <message>
      <source>Returning to launch</source>
      <translation>Повернення до запуску</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3623245/message</name>
    <message>
      <source>Invalid configuration: Airspeed max smaller than min</source>
      <translation>Некоректна конфігурація: максимальна швидкість польоту менша за мінімальну</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3623245/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</source>
      <translation>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3645914/message</name>
    <message>
      <source>High latency data link lost</source>
      <translation>Висока затримка втрачено з'єднання даних</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3779911/message</name>
    <message>
      <source>Hover thrust has been constrained by min/max thrust</source>
      <translation>Тяга при зависанні обмежена min/max тягою</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3779911/description</name>
    <message>
      <source>&lt;param&gt;MPC_THR_HOVER&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3817890/message</name>
    <message>
      <source>Invalid mission state</source>
      <translation>Неприпустимий стан місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3817890/description</name>
    <message>
      <source>No mission or storage failure</source>
      <translation>Немає місії або збїй сховища</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3878855/message</name>
    <message>
      <source>Using default takeoff altitude: {1:.2m}</source>
      <translation>Використання висоти зльоту за замовчуванням: {1:.2m}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3914228/message</name>
    <message>
      <source>Rejecting mission request command, component or system ID mismatch</source>
      <translation>Відхилення запиту команд місії, розбіжність компоненту чи системного ID</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3939705/message</name>
    <message>
      <source>Land tilt limit has been constrained by maximum tilt</source>
      <translation>Ліміт нахилу над поверхнею обмежений максимальним нахилом</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3939705/description</name>
    <message>
      <source>&lt;param&gt;MPC_TILTMAX_LND&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4075829/message</name>
    <message>
      <source>Provided autotune command is not supported. To enable autotune in mission, set param1 to 1</source>
      <translation type="unfinished">Provided autotune command is not supported. To enable autotune in mission, set param1 to 1</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4086702/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_P</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_P</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4089486/message</name>
    <message>
      <source>Rejecting waypoint command, component or system ID mismatch</source>
      <translation>Відхилення команд точок маршруту, компоненту чи розбіжність системного ID</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4163547/message</name>
    <message>
      <source>Start loiter with fixed bank angle</source>
      <translation>Почніть баражувати з фіксованого кута крену</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4202815/message</name>
    <message>
      <source>Ignoring mission clear command, busy</source>
      <translation>Ігнорування команди місію завершено (mission clear), зайнято</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4277609/message</name>
    <message>
      <source>Takeoff detected</source>
      <translation>Виявлено зліт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/439666/message</name>
    <message>
      <source>Ignoring mission item, no transfer in progress</source>
      <translation>Ігнорування предмету місії, немає прогресу у трансфері</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4502496/message</name>
    <message>
      <source>Failsafe activated: switching to {2} in {3} seconds</source>
      <translation>Аварійний режим активовано: перемикання на {2} через {3} секунд</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4502889/message</name>
    <message>
      <source>Blank storage, parameters reset to default</source>
      <translation type="unfinished">Blank storage, parameters reset to default</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4519150/message</name>
    <message>
      <source>Invalid configuration: Airspeed trim out of min or max bounds</source>
      <translation>Некоректна конфігурація: обмеження польотної швидкості поза межами min або max меж</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4519150/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}
- &lt;param&gt;FW_AIRSPD_TRIM&lt;/param&gt;: {3:.1}</source>
      <translation>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}
- &lt;param&gt;FW_AIRSPD_TRIM&lt;/param&gt;: {3:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4535132/message</name>
    <message>
      <source>logging: opening log file sess{1}/log{2}.ulg</source>
      <translation>ведення журналу записів: відкриття файлу журналу записів sess{1}/log{2}.ulg</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4678390/message</name>
    <message>
      <source>Mission finished, loitering</source>
      <translation>Місія завершена, баражування</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4704426/message</name>
    <message>
      <source>Geofence imported</source>
      <translation>Геоогорожу імпортовано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4774181/message</name>
    <message>
      <source>Mission rejected: the landing glide slope is steeper than the vehicle setting of {1}.{2} degrees</source>
      <translation>Місія відхилена: нахил приземлення крутіший, ніж налаштування апарату {1}.{2} градусів</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4790285/message</name>
    <message>
      <source>Traffic Conflict Resolved {1}!</source>
      <translation>Конфлікт трафіку вирішений {1}!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4796299/message</name>
    <message>
      <source>Mission upload busy, already receiving waypoint</source>
      <translation>Завантаження місії зайняте, їде отримання точки маршруту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4854315/message</name>
    <message>
      <source>No valid mission available, refusing takeoff</source>
      <translation>Немає належних місій, відхилення зльоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4934924/message</name>
    <message>
      <source>Gyro {1} clipping, not safe to fly!</source>
      <translation>Гіроскоп {1} обрізає дані, летіти небезпечно!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4934924/description</name>
    <message>
      <source>Land now, and check the vehicle setup. Clipping can lead to fly-aways.</source>
      <translation>Приземліться зараз та перевірте налаштування апарату. Обрізання даних може призвести до задалеких відльотів.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5063943/message</name>
    <message>
      <source>Error saving settings</source>
      <translation>Помилка збереження налаштувань</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5065788/message</name>
    <message>
      <source>Manual sideways speed has been constrained by forward speed</source>
      <translation>Ручна бокова швидкість була обмежена прямою швидкістю</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5065788/description</name>
    <message>
      <source>&lt;param&gt;MPC_VEL_MAN_SIDE&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5108026/message</name>
    <message>
      <source>ESCs calibration denied</source>
      <translation>ESCs калібрування відхилено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/51327/message</name>
    <message>
      <source>Emergency battery level, land immediately</source>
      <translation>Екстрений рівень батареї, приземлитися негайно</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5137632/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_SPEED_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_SPEED_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5158211/message</name>
    <message>
      <source>No airspeed sensor detected, switching to non-airspeed mode</source>
      <translation>Не виявлено датчика швидкості польоту, перемикання на режим без швидкості польоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5314313/message</name>
    <message>
      <source>First waypoint far away from Home: {1m} Correct mission loaded?</source>
      <translation type="unfinished">First waypoint far away from Home: {1m} Correct mission loaded?</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5314313/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;MIS_DIST_1WP&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;MIS_DIST_1WP&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5371654/message</name>
    <message>
      <source>Magnetometer sensor #{1} failure: {2}</source>
      <translation>Датчик магнітометра #{1} дає збій: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5371654/description</name>
    <message>
      <source>Land immediately and check the system.</source>
      <translation>Терміново приземляйтеся та перевірте систему.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5383828/message</name>
    <message>
      <source>RTL: start return at {1m_v} ({2m_v} above destination)</source>
      <translation>RTL: початок повернення в {1m_v} ({2m_v} над пунктом призначення)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5494498/message</name>
    <message>
      <source>Mission rejected: Takeoff waypoint required</source>
      <translation>Місію відхилено: Необхідна точка маршруту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5623108/message</name>
    <message>
      <source>Manual control lost</source>
      <translation>Втрачено ручне керування</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5650341/message</name>
    <message>
      <source>SET_POSITION_TARGET_LOCAL_NED: invalid, missing position, velocity or acceleration</source>
      <translation>SET_POSITION_TARGET_LOCAL_NED: неприпустимий, відсутня позиція, швидкість або прискорення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5726704/message</name>
    <message>
      <source>High wind speed detected ({1:.1m/s}), landing advised</source>
      <translation>Виявлено високу швидкість вітру ({1:.1м/с}), радимо приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5734437/message</name>
    <message>
      <source>Command denied during calibration: {1}</source>
      <translation>Команду відхилено під час калібрування: {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5747358/message</name>
    <message>
      <source>RTL destination breaches geofence, will fly directly</source>
      <translation type="unfinished">RTL destination breaches geofence, will fly directly</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5795201/message</name>
    <message>
      <source>Geofence requires a valid home position</source>
      <translation>Геоогорожа потребує дійсної точки зльоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5814991/message</name>
    <message>
      <source>Ascent speed has been constrained by max speed</source>
      <translation>Швидкість зниження обмежена максимальною швидкістю</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5814991/description</name>
    <message>
      <source>&lt;param&gt;MPC_Z_V_AUTO_UP&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5847165/message</name>
    <message>
      <source>Dangerously low battery! System shut down failed</source>
      <translation>Небезпечно низький заряд батареї! Система відключена</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5847165/description</name>
    <message>
      <source>Cannot shut down, most likely the system does not support it.</source>
      <translation>Неможливо вимкнути, швидше за все, система це не підтримує.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5911339/message</name>
    <message>
      <source>Received unknown mission type, abort</source>
      <translation>Отримано невідомий тип місії, переривання</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6006807/message</name>
    <message>
      <source>Quad-chute triggered due to maximum pitch angle exceeded</source>
      <translation>Quad-chute спрацював через перевищення максимального кута тангажу</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6124520/message</name>
    <message>
      <source>Mission rejected: starts with landing</source>
      <translation>Місія відхилена: починається з приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/613779/message</name>
    <message>
      <source>Mission rejected: unsupported landing approach entrance waypoint type. Only ORBIT_TO_ALT or WAYPOINT allowed</source>
      <translation>Місія відхилена: непідтримуваний тип точки маршруту при наближенні до входу у приземлення. Дозволено лише ORBIT_TO_ALT або WAYPOINT</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/621270/message</name>
    <message>
      <source>Arm stick gesture disabled if arm switch in use</source>
      <translation type="unfinished">Arm stick gesture disabled if arm switch in use</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/621270/description</name>
    <message>
      <source>&lt;param&gt;MAN_ARM_GESTURE&lt;/param&gt; is now set to disable arm/disarm stick gesture.</source>
      <translation type="unfinished">&lt;param&gt;MAN_ARM_GESTURE&lt;/param&gt; is now set to disable arm/disarm stick gesture.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6349555/message</name>
    <message>
      <source>Calibration: Restoring RC input</source>
      <translation>Калібрування: Відновлення входу пульта(RC)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6363289/message</name>
    <message>
      <source>Airspeed estimation valid</source>
      <translation>Дійсне вимірювання швидкості польоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6415112/message</name>
    <message>
      <source>RC trim calibration completed</source>
      <translation>Калібрування корекції пульта(RC) завершено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6830556/message</name>
    <message>
      <source>Target relative: unsupported type {1}</source>
      <translation type="unfinished">Target relative: unsupported type {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6843301/message</name>
    <message>
      <source>Parachute system regained</source>
      <translation>Відновлена система парашуту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6847604/message</name>
    <message>
      <source>Quad-chute triggered due to maximum roll angle exceeded</source>
      <translation>Quad-chute спрацював через перевищення максимального кута крену</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6880628/message</name>
    <message>
      <source>Approaching max flight time (system will RTL in {1} minutes)</source>
      <translation>Наближається максимальний час польоту (система RTL (повернеться на точку запуску) за {1} хвилину)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6880628/description</name>
    <message>
      <source>Maximal flight time warning (more than 1min remaining)</source>
      <translation>Попередження про максимальний час польоту (більше 1 хв. залишилось)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6922012/message</name>
    <message>
      <source>DO JUMP waypoint could not be written</source>
      <translation>Точка маршруту DO JUMP не може бути записана</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6974862/message</name>
    <message>
      <source>Unexpected waypoint index, aborting transfer</source>
      <translation>Неочікуваний індекс точки маршруту, переривання передачі</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/697858/message</name>
    <message>
      <source>RC trim calibration: failed to set parameters</source>
      <translation>Калібрування корекції пульта(RC): не вдалось встановити параметри</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7015692/message</name>
    <message>
      <source>Rejecting mission item, component or system ID mismatch</source>
      <translation type="unfinished">Rejecting mission item, component or system ID mismatch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7028282/message</name>
    <message>
      <source>Airspeed sensor failure detected. Check connection and reboot</source>
      <translation>Виявлено помилку датчика швидкості польоту. Перевірте з'єднання та перезавантажте</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7067274/message</name>
    <message>
      <source>Mission start denied! No valid mission</source>
      <translation>Старт місії відхилено! Немає належної місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/710679/message</name>
    <message>
      <source>Mission failure: unable to reach heading within timeout</source>
      <translation>Помилка місії: неможливо досягти напрямку в межах тайм-ауту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/713405/message</name>
    <message>
      <source>Manual control regained after {1:.1} s</source>
      <translation>Ручне управління відновлено після {1:.1} с</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7144644/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, landing</source>
      <translation>Попередження про трафік - ICAO Адреса {1}! Дистанція Розділення {2}, Напрямок {3}, приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7144644/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation>- ICAO Адреса: {1}
- Дистанція Розділення Трафіку: {2m}
- Напрямок: {3} градусів</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7186357/message</name>
    <message>
      <source>Yaw Airmode requires disabling the stick arm gesture</source>
      <translation>Режим рискання потребує вимкнення руху взведення стіком</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7186357/description</name>
    <message>
      <source>&lt;param&gt;MC_AIRMODE&lt;/param&gt; is now set to roll/pitch airmode.</source>
      <translation>&lt;param&gt;MC_AIRMODE&lt;/param&gt; зараз налаштовано на режим крен/тангаж.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/73581/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_RATE_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_RATE_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7364518/message</name>
    <message>
      <source>Invalid configuration for rate control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_YAW_RATE_P) is setup</source>
      <translation type="unfinished">Invalid configuration for rate control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_YAW_RATE_P) is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7714236/message</name>
    <message>
      <source>Approaching max flight time (system will RTL in {1} seconds)</source>
      <translation>Наближається максимальний час польоту (система зробить RTL (повернеться на точку запуску) за {1} секунд)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7714236/description</name>
    <message>
      <source>Maximal flight time warning (less than 1min remaining)</source>
      <translation>Попередження про максимальний час польоту (менше ніж 1хв залишилось)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7791755/message</name>
    <message>
      <source>Airspeed sensor healthy, start using again</source>
      <translation>Датчик швидкості польоту в нормі, почніть використовувати знову</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7791755/description</name>
    <message>
      <source>Previously selected sensor index: {1}, current sensor index: {2}.</source>
      <translation>Попередньо обраний індекс датчиків:{1}, поточний індекс датчиків: {2}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7803396/message</name>
    <message>
      <source>Mission finished, landed</source>
      <translation>Місія завершена, приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7832778/message</name>
    <message>
      <source>Traffic Conflict {1} Expired and removed from buffer</source>
      <translation>Конфлікт трафіку {1} має закінчений термін та був прибраний з буфера обміну</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7853111/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_SPEED_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_SPEED_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7860665/message</name>
    <message>
      <source>Mission rejected: land start item before RTL item is not possible</source>
      <translation>Місія відхилена: елемент старту з землі перед елементом RTL неможливий</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7939557/message</name>
    <message>
      <source>Invalid configuration for rate control: Neither feed forward nor feedback is setup</source>
      <translation type="unfinished">Invalid configuration for rate control: Neither feed forward nor feedback is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8208988/message</name>
    <message>
      <source>Climb to {1:.1m_v} above home</source>
      <translation>Перейти до {1:.1m_v} вище точки повернення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8280920/message</name>
    <message>
      <source>Airspeed estimation invalid</source>
      <translation>Оцінка швидкості польоту не вдала</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8310204/message</name>
    <message>
      <source>Landing using precision landing</source>
      <translation>Приземлення з використанням точного приземлення</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8324861/message</name>
    <message>
      <source>Not yet ready for mission, no position lock</source>
      <translation>Ще немає готовності для місії, немає замикання позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8459921/message</name>
    <message>
      <source>Mission rejected: Landing waypoint/pattern required</source>
      <translation>Місію відхилено: Необхідна точка приземлення/шаблону</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8518010/message</name>
    <message>
      <source>RTL: no geofence avoidance path; flying directly</source>
      <translation type="unfinished">RTL: no geofence avoidance path; flying directly</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8546752/message</name>
    <message>
      <source>Ignoring mission item, busy</source>
      <translation>Ігнорування предмету місії, зайнятий</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8557551/message</name>
    <message>
      <source>Failsafe warning: {2}</source>
      <translation>Попередження аварійного режиму: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8557551/description</name>
    <message>
      <source>No action is triggered.</source>
      <translation>Жодної дії не викликано.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8673473/message</name>
    <message>
      <source>Not enough bandwidth to enable log streaming ({1} \&lt; 5000)</source>
      <translation>Не вистачає пропускної здатності для увімкнення потокового передавання журналу ({1} \&lt; 5000)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8706060/message</name>
    <message>
      <source>Manual backward speed has been constrained by forward speed</source>
      <translation>Ручна бокова швидкість була обмежена прямою швидкістю</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8706060/description</name>
    <message>
      <source>&lt;param&gt;MPC_VEL_MAN_BACK&lt;/param&gt; is set to {1:.0}.</source>
      <translation>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; встановлено на {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8775715/message</name>
    <message>
      <source>Mission rejected: item {1}: unsupported command: {2}</source>
      <translation>Місія відхилена: елемент {1}: непідтримувана команда: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8833276/message</name>
    <message>
      <source>No inputs, aborting RC trim calibration</source>
      <translation>Немає вхідних даних, переривання калібрування корекції пульта(RC)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8865457/message</name>
    <message>
      <source>Geofence: import error</source>
      <translation>Геоогорожа: помилка імпорту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8894709/message</name>
    <message>
      <source>Mission rejected: the landing point must be outside the orbit radius</source>
      <translation>Місія відхилена: точка приземлення має бути поза радіусом орбіти</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8935528/message</name>
    <message>
      <source>Mission manager currently busy, ignoring new waypoint index</source>
      <translation>Менеджер місії зараз зайнятий, ігнорує новий індекс точки маршруту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8968453/message</name>
    <message>
      <source>Invalid configuration: FW_AIRSPD_MAX too low to sustain max bank angle</source>
      <translation type="unfinished">Invalid configuration: FW_AIRSPD_MAX too low to sustain max bank angle</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8968453/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {2:.1}
- &lt;param&gt;FW_R_LIM&lt;/param&gt;: {3:.1}</source>
      <translation type="unfinished">- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {2:.1}
- &lt;param&gt;FW_R_LIM&lt;/param&gt;: {3:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9013084/message</name>
    <message>
      <source>Ignoring mission request, currently busy</source>
      <translation>Ігнорування запиту місії, наразі зайнятий</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9091509/message</name>
    <message>
      <source>Disarming denied: not landed</source>
      <translation>Охолощення недоступно: не приземлено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9092852/message</name>
    <message>
      <source>Unexpected waypoint index, aborting mission transfer</source>
      <translation>Неочікуваний індекс точки маршруту, переривання трансферу місії</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9180535/message</name>
    <message>
      <source>GNSS signal spoofed</source>
      <translation type="unfinished">GNSS signal spoofed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/929525/message</name>
    <message>
      <source>Estimated position error is approaching the failsafe threshold</source>
      <translation>Помилка оціненої позиції наближається до порогу аварійного режиму</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/929525/description</name>
    <message>
      <source>Switch to manual mode recommended.

&lt;profile name="dev"&gt; This warning is triggered when the position error estimate is 90% of (or only 10m below) &lt;param&gt;COM_POS_FS_EPH&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Рекомендовано перемикнутися на ручний режим.

&lt;profile name="dev"&gt; Це попередження викликається коли оцінка помилки позиції є 90% з (або тільки 10м нижче) &lt;param&gt;COM_POS_FS_EPH&lt;/param&gt; параметра.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9346577/message</name>
    <message>
      <source>Reached clearance altitude</source>
      <translation>Досягнуто висоти прольоту перешкод</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9355528/message</name>
    <message>
      <source>Could not set mission closest to position</source>
      <translation>Не вдалося встановити місію якнайближче до позиції</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9421773/message</name>
    <message>
      <source>Baro sensor #{1} failure: {2}</source>
      <translation>Барометр #{1} дає збій: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9421773/description</name>
    <message>
      <source>Land immediately and check the system.</source>
      <translation>Терміново приземляйтеся та перевірте систему.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9427265/message</name>
    <message>
      <source>Mission could not reset jump count</source>
      <translation>Місія не може перевстановити лічильник стрибків</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9432105/message</name>
    <message>
      <source>Geofence invalid, doesn't contain current vehicle position</source>
      <translation>Неприйнятна геоогорожа, не містить поточної позиції апарату</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9476947/message</name>
    <message>
      <source>Quad-chute triggered due to uncommanded descent detection</source>
      <translation>Quad-chute викликано через виявлення мимовільного зниження</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9489139/message</name>
    <message>
      <source>Armed by {1}</source>
      <translation>Взведений за допомогою {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9537079/message</name>
    <message>
      <source>Obstacle message received in unsupported frame {1}</source>
      <translation>Повідомлення про перешкоду отримано у рамці, що не підтримується {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/961599/message</name>
    <message>
      <source>Pilot took over using sticks</source>
      <translation>Пілот прийняв управління за допомогою стіків</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9621455/message</name>
    <message>
      <source>5V overcurrent detected, landing advised</source>
      <translation type="unfinished">5V overcurrent detected, landing advised</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9751178/message</name>
    <message>
      <source>{3}: switching to {2}</source>
      <translation>{3}: switching to {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9758530/message</name>
    <message>
      <source>Mission item could not be set</source>
      <translation>Елемент місії не може бути встановлений</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9828325/message</name>
    <message>
      <source>GNSS signal jammed</source>
      <translation type="unfinished">GNSS signal jammed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9844908/message</name>
    <message>
      <source>Landing detected</source>
      <translation>Приземлення виявлено</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/10161216/message</name>
    <message>
      <source>Open Drone ID system missing</source>
      <translation type="unfinished">Open Drone ID system missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/10161216/description</name>
    <message>
      <source>Open Drone ID system failed to report. Make sure it is setup and installed properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Open Drone ID system failed to report. Make sure it is setup and installed properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/10318274/message</name>
    <message>
      <source>Battery {3} missing</source>
      <translation type="unfinished">Battery {3} missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/10318274/description</name>
    <message>
      <source>Make sure all required batteries are connected.</source>
      <translation type="unfinished">Make sure all required batteries are connected.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1058956/message</name>
    <message>
      <source>CPU load too high: {3:.1}%</source>
      <translation>Занадто велике навантаження на ЦП: {3:.1}%</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1058956/description</name>
    <message>
      <source>The CPU load can be reduced for example by disabling unused modules (e.g. mavlink instances) or reducing the gyro update rate via &lt;param&gt;IMU_GYRO_RATEMAX&lt;/param&gt;.

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_CPU_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Навантаження на ЦП(CPU) може бути зменшено наприклад через відключення незалучений модулей (напр. mavlink екземпляри) або зменшення частоти оновлення гірокомпаса через &lt;param&gt;IMU_GYRO_RATEMAX&lt;/param&gt;.

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_CPU_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/11125932/message</name>
    <message>
      <source>No valid data from optical flow sensor</source>
      <translation type="unfinished">No valid data from optical flow sensor</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1127257/message</name>
    <message>
      <source>GPS {3} lost fix</source>
      <translation type="unfinished">GPS {3} lost fix</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1127257/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Configure the minimum required GPS count with &lt;param&gt;SYS_HAS_NUM_GNSS&lt;/param&gt;. Configure the failsafe action with &lt;param&gt;COM_GNSSLOSS_ACT&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Configure the minimum required GPS count with &lt;param&gt;SYS_HAS_NUM_GNSS&lt;/param&gt;. Configure the failsafe action with &lt;param&gt;COM_GNSSLOSS_ACT&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/11478328/message</name>
    <message>
      <source>No valid data from Gyro {3}</source>
      <translation>Немає належних даних від Гірокомпаса {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13344346/message</name>
    <message>
      <source>Battery unhealthy</source>
      <translation>Батарея має проблеми</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13344346/description</name>
    <message>
      <source>Make sure all batteries are operational.</source>
      <translation type="unfinished">Make sure all batteries are operational.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13372152/message</name>
    <message>
      <source>Parachute system not ready</source>
      <translation>Парашутна система не готова</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13372152/description</name>
    <message>
      <source>MAVLink parachute system reports unhealthy status.

&lt;profile name="dev"&gt; Configured by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</source>
      <translation type="unfinished">MAVLink parachute system reports unhealthy status.

&lt;profile name="dev"&gt; Configured by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14221469/message</name>
    <message>
      <source>Distance sensor {3} missing</source>
      <translation>Сенсор відстані {3} відсутній</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14221469/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_NUM_DIST&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;SYS_HAS_NUM_DIST&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14421482/message</name>
    <message>
      <source>RAM usage too high: {3:.1}%</source>
      <translation type="unfinished">RAM usage too high: {3:.1}%</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14421482/description</name>
    <message>
      <source>The RAM usage can be reduced for example by disabling unused modules (e.g. mavlink instances).

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_RAM_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The RAM usage can be reduced for example by disabling unused modules (e.g. mavlink instances).

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_RAM_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14566046/message</name>
    <message>
      <source>ESC {3} offline</source>
      <translation>ESC {3} офлайн</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14566046/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1457161/message</name>
    <message>
      <source>GPS receivers disagree by {3:.1}m</source>
      <translation type="unfinished">GPS receivers disagree by {3:.1}m</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1457161/description</name>
    <message>
      <source>Two GNSS receivers report positions that are inconsistent with their reported accuracy.

&lt;profile name="dev"&gt; Configure the failsafe action with &lt;param&gt;COM_GNSSLOSS_ACT&lt;/param&gt;. The failsafe action is only triggered when &lt;param&gt;SYS_HAS_NUM_GNSS&lt;/param&gt; is set to 2.
&lt;/profile&gt;</source>
      <translation type="unfinished">Two GNSS receivers report positions that are inconsistent with their reported accuracy.

&lt;profile name="dev"&gt; Configure the failsafe action with &lt;param&gt;COM_GNSSLOSS_ACT&lt;/param&gt;. The failsafe action is only triggered when &lt;param&gt;SYS_HAS_NUM_GNSS&lt;/param&gt; is set to 2.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15289843/message</name>
    <message>
      <source>Avionics Power high: {3:.2} Volt</source>
      <translation>Потужність авіоніки велика: {3:.2} Volt</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15289843/description</name>
    <message>
      <source>Check the voltage supply to the FMU, it must be below {4:.2} Volt.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Перевірте вольтаж живлення FMU, він має бути нижче за {4:.2} Volt.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15388760/message</name>
    <message>
      <source>Compass sensor {3} missing</source>
      <translation>Сенсор відстані {3} відсутній</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15602498/message</name>
    <message>
      <source>Battery {3}: {4}. {5}</source>
      <translation>Батарея {3}: {4}. {5}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15602498/description</name>
    <message>
      <source>The battery reported a failure which might be dangerous to fly with.</source>
      <translation type="unfinished">The battery reported a failure which might be dangerous to fly with.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15793174/message</name>
    <message>
      <source>ESC {3}: {4}</source>
      <translation type="unfinished">ESC {3}: {4}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15793174/description</name>
    <message>
      <source>{5}

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">{5}

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15965684/message</name>
    <message>
      <source>Parachute system missing</source>
      <translation>Парашутна система відсутня</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15965684/description</name>
    <message>
      <source>No MAVLink parachute heartbeat detected. Check connection, power, configuration.

&lt;profile name="dev"&gt; Configured by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</source>
      <translation type="unfinished">No MAVLink parachute heartbeat detected. Check connection, power, configuration.

&lt;profile name="dev"&gt; Configured by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/16230031/message</name>
    <message>
      <source>No valid data from Accelerometer {3}</source>
      <translation>Немає належних даних з акселерометра {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1670367/message</name>
    <message>
      <source>Avionics Power low: {3:.2} Volt</source>
      <translation>Потужність авіоніки низька: {3:.2} Вольт</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1670367/description</name>
    <message>
      <source>Check the voltage supply to the FMU, it must be above {4:.2} Volt.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Перевірте вольтаж живлення FMU, він має бути вище за {4:.2} Volt.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1914663/message</name>
    <message>
      <source>Health report summary event</source>
      <translation>Підсумкова подія звіту про стан</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3081997/message</name>
    <message>
      <source>Motor {3} overcurrent detected</source>
      <translation type="unfinished">Motor {3} overcurrent detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3081997/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3189229/message</name>
    <message>
      <source>No valid data from barometer {3}</source>
      <translation>Немає належних даних з барометра {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3568720/message</name>
    <message>
      <source>Gyro sensor {3} missing</source>
      <translation>Сенсор гірокомпаса {3} відсутній</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3713724/message</name>
    <message>
      <source>Companion computer temperature warning, {3} C</source>
      <translation type="unfinished">Companion computer temperature warning, {3} C</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3713724/description</name>
    <message>
      <source>The companion computer temperature is above the warning threshold.

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_CC_TEMP_WARN&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The companion computer temperature is above the warning threshold.

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_CC_TEMP_WARN&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4096753/message</name>
    <message>
      <source>GPS {3} offline</source>
      <translation type="unfinished">GPS {3} offline</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4096753/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Configure the minimum required GPS count with &lt;param&gt;SYS_HAS_NUM_GNSS&lt;/param&gt;. Configure the failsafe action with &lt;param&gt;COM_GNSSLOSS_ACT&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Configure the minimum required GPS count with &lt;param&gt;SYS_HAS_NUM_GNSS&lt;/param&gt;. Configure the failsafe action with &lt;param&gt;COM_GNSSLOSS_ACT&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4448091/message</name>
    <message>
      <source>Crash dumps present on SD card</source>
      <translation>Аварійні вивантаження даних присутні на SD карті</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4448091/description</name>
    <message>
      <source>The SD card contains crash dump files, service the vehicle before continuing to fly.

&lt;profile name="dev"&gt; Check how to debug hardfaults on &lt;a&gt;https://docs.px4.io/main/en/debug/gdb_debugging.html#hard-fault-debugging&lt;/a&gt;. When completed, remove the files 'fault_*.log' on the SD card.

This check can be configured via &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>SD-карта містить файли аварійного вивантаження, обслужіть апарат перед продовженням польоту.

&lt;profile name="dev"&gt; Перевірте як виправити hard faults на &lt;a&gt;https://docs.px4.io/main/en/debug/gdb_debugging. tml#hard-fault-debugging&lt;/a&gt;. Після завершення видаліть файли 'fault_*.log' на SD-карті.

Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4643123/message</name>
    <message>
      <source>Airspeed invalid</source>
      <translation>Неналежна швидкість польоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4877352/message</name>
    <message>
      <source>Imbalanced propeller detected</source>
      <translation>Виявлено незбалансованого пропелера</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4877352/description</name>
    <message>
      <source>Check that all propellers are mounted correctly and are not damaged.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_IMB_PROP_THR&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Check that all propellers are mounted correctly and are not damaged.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_IMB_PROP_THR&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/5095593/message</name>
    <message>
      <source>Barometer {3} missing</source>
      <translation>Відсутній барометр {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/5699115/message</name>
    <message>
      <source>Overcurrent detected for the peripheral 5V supply</source>
      <translation type="unfinished">Overcurrent detected for the peripheral 5V supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/5699115/description</name>
    <message>
      <source>Check the power supply</source>
      <translation type="unfinished">Check the power supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6410608/message</name>
    <message>
      <source>No valid data from Compass {3}</source>
      <translation>Немає належних даних від Компаса {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6443801/message</name>
    <message>
      <source>Motor {3} undercurrent detected</source>
      <translation type="unfinished">Motor {3} undercurrent detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6443801/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6632208/message</name>
    <message>
      <source>Not all ESCs are armed</source>
      <translation type="unfinished">Not all ESCs are armed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6632208/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6962647/message</name>
    <message>
      <source>Overcurrent detected for the hipower 5V supply</source>
      <translation type="unfinished">Overcurrent detected for the hipower 5V supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6962647/description</name>
    <message>
      <source>Check the power supply</source>
      <translation type="unfinished">Check the power supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7196697/message</name>
    <message>
      <source>ESC {3} temperature warning, {4:C}</source>
      <translation type="unfinished">ESC {3} temperature warning, {4:C}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7196697/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Configured by &lt;param&gt;ESC_TEMP_WARN_TH&lt;/param&gt;
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Configured by &lt;param&gt;ESC_TEMP_WARN_TH&lt;/param&gt;
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7214714/message</name>
    <message>
      <source>System power unavailable</source>
      <translation>Живлення системи відсутнє</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7214714/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Ensure the ADC is working and the system_power topic is published.

This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Переконайтесь що ADC працює та заголовок живлення_системи опубліковано.

Ця перевірка може бути налаштована через &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7908333/message</name>
    <message>
      <source>Power module not connected</source>
      <translation>Модуль живлення не під'єднано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7908333/description</name>
    <message>
      <source>Note that USB must be disconnected as well.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>Зверніть увагу, що USB має бути також від'єднано.

&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8227839/message</name>
    <message>
      <source>Accelerometer sensor {3} missing</source>
      <translation>Датчик акселерометра {3} відсутній</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8441780/message</name>
    <message>
      <source>Open Drone ID system not ready</source>
      <translation type="unfinished">Open Drone ID system not ready</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8441780/description</name>
    <message>
      <source>Open Drone ID system reported being unhealthy.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Open Drone ID system reported being unhealthy.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8544646/message</name>
    <message>
      <source>No valid data from distance sensor {3}</source>
      <translation>Немає дійсних даних від датчика відстані {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8792768/message</name>
    <message>
      <source>Optical flow sensor missing</source>
      <translation type="unfinished">Optical flow sensor missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8792768/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_NUM_OF&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_NUM_OF&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8799553/message</name>
    <message>
      <source>Battery {3} disconnected</source>
      <translation>Батарею {3} від’єднано</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9191449/message</name>
    <message>
      <source>ESC telemetry missing</source>
      <translation>ESC телеметрія відсутня</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9191449/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Ця перевірка може бути налаштована через &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9266821/message</name>
    <message>
      <source>No CPU and RAM load information</source>
      <translation type="unfinished">No CPU and RAM load information</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9266821/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; If the system does not provide any CPU and RAM load information, use the parameters &lt;param&gt;COM_CPU_MAX&lt;/param&gt; and &lt;param&gt;COM_RAM_MAX&lt;/param&gt; to disable the checks.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; If the system does not provide any CPU and RAM load information, use the parameters &lt;param&gt;COM_CPU_MAX&lt;/param&gt; and &lt;param&gt;COM_RAM_MAX&lt;/param&gt; to disable the checks.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9409869/message</name>
    <message>
      <source>Task watchdog dumps present on SD card</source>
      <translation type="unfinished">Task watchdog dumps present on SD card</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9409869/description</name>
    <message>
      <source>The SD card contains task watchdog dump files from a previous task starvation event.

&lt;profile name="dev"&gt; Remove the files in the 'task_watchdog' directory on the SD card after analysis.

This check can be configured via &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The SD card contains task watchdog dump files from a previous task starvation event.

&lt;profile name="dev"&gt; Remove the files in the 'task_watchdog' directory on the SD card after analysis.

This check can be configured via &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9493632/message</name>
    <message>
      <source>No airspeed data</source>
      <translation>Немає даних про швидкість польоту</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9493632/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Most likely the airspeed selector module is not running. This check can be configured via &lt;param&gt;SYS_HAS_NUM_ASPD&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation>&lt;profile name="dev"&gt; Вірогідно що модуль селектора швидкості польоту не працює. Ця перевірка може бути налаштована через &lt;param&gt;SYS_HAS_NUM_ASPD&lt;/param&gt; параметр.
&lt;/profile&gt;</translation>
    </message>
  </context>
</TS>
