<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh-CN" sourcelanguage="en">
  <context>
    <name>/components/0/enums/calibration_action_t/entries/0/description</name>
    <message>
      <source>Side already completed, switch to one of the remaining sides</source>
      <translation>侧边已完成，切换到剩余侧面</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_action_t/entries/1/description</name>
    <message>
      <source>Switch to next orientation</source>
      <translation>切换到下一个方向</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_action_t/entries/2/description</name>
    <message>
      <source>Rotate as shown</source>
      <translation>按显示旋转</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_action_t/entries/3/description</name>
    <message>
      <source>Hold still</source>
      <translation>保持静止</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_result_t/entries/0/description</name>
    <message>
      <source>Success</source>
      <translation>操作成功</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_result_t/entries/1/description</name>
    <message>
      <source>Failed</source>
      <translation>操作失败</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_result_t/entries/2/description</name>
    <message>
      <source>Aborted</source>
      <translation>已终止</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/1/description</name>
    <message>
      <source>Tail Down</source>
      <translation type="unfinished">Tail Down</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/16/description</name>
    <message>
      <source>Upside Down</source>
      <translation type="unfinished">Upside Down</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/2/description</name>
    <message>
      <source>Nose Down</source>
      <translation type="unfinished">Nose Down</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/32/description</name>
    <message>
      <source>Down</source>
      <translation>下移</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/4/description</name>
    <message>
      <source>Left Side Down</source>
      <translation>左侧下移</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_sides_t/entries/8/description</name>
    <message>
      <source>Right Side Down</source>
      <translation>右侧下移</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/1/description</name>
    <message>
      <source>Accelerometer</source>
      <translation>加速度计</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/16/description</name>
    <message>
      <source>Airspeed</source>
      <translation>空速</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/2/description</name>
    <message>
      <source>Magnetometer</source>
      <translation>磁力计</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/32/description</name>
    <message>
      <source>RC</source>
      <translation>遥控器</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/4/description</name>
    <message>
      <source>Gyroscope</source>
      <translation>陀螺仪</translation>
    </message>
  </context>
  <context>
    <name>/components/0/enums/calibration_type_t/entries/8/description</name>
    <message>
      <source>Level</source>
      <translation>级别</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1100/message</name>
    <message>
      <source>Calibration progress: {2}%</source>
      <translation>校准进度： {2}%</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1101/message</name>
    <message>
      <source>Orientation detected: {1}</source>
      <translation>已检测到方向: {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1102/message</name>
    <message>
      <source>Orientation Complete: {1}, next step: {2}</source>
      <translation>方向完整： {1}，下一步： {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/0/event_groups/calibration/events/1103/message</name>
    <message>
      <source>Calibration Complete: {1}</source>
      <translation>校准完成︰ {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/1/description</name>
    <message>
      <source>stick gesture</source>
      <translation type="unfinished">stick gesture</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/13/description</name>
    <message>
      <source>RC button</source>
      <translation type="unfinished">RC button</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/14/description</name>
    <message>
      <source>failsafe</source>
      <translation>故障安全</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/2/description</name>
    <message>
      <source>RC switch</source>
      <translation type="unfinished">RC switch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/3/description</name>
    <message>
      <source>internal command</source>
      <translation>内部指令</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/4/description</name>
    <message>
      <source>external command</source>
      <translation>外部指令</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/5/description</name>
    <message>
      <source>mission start</source>
      <translation>任务开始</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/6/description</name>
    <message>
      <source>landing</source>
      <translation>降落</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/7/description</name>
    <message>
      <source>preflight inaction</source>
      <translation type="unfinished">preflight inaction</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arm_disarm_reason_t/entries/8/description</name>
    <message>
      <source>kill switch</source>
      <translation>应急开关</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/0/description</name>
    <message>
      <source>Init</source>
      <translation>初始化</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/1/description</name>
    <message>
      <source>Standby</source>
      <translation>待机</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/2/description</name>
    <message>
      <source>Armed</source>
      <translation>装备</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/3/description</name>
    <message>
      <source>Standby Error</source>
      <translation>待机错误</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/4/description</name>
    <message>
      <source>Shutdown</source>
      <translation>关机</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/arming_state_t/entries/5/description</name>
    <message>
      <source>In-air Restore</source>
      <translation>空中恢复</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/0/description</name>
    <message>
      <source>Battery has deep discharged</source>
      <translation>电池已过度放电</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/1/description</name>
    <message>
      <source>Battery detected voltage spikes</source>
      <translation>电池检测到电压跃位</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/10/description</name>
    <message>
      <source>Battery failed to arm</source>
      <translation type="unfinished">Battery failed to arm</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/2/description</name>
    <message>
      <source>One or more battery cells have failed</source>
      <translation>一个或多个电池已失败</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/3/description</name>
    <message>
      <source>Battery reported over-current</source>
      <translation>电池过载</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/4/description</name>
    <message>
      <source>Battery has reached a critical temperature which can result in a critical failure</source>
      <translation type="unfinished">Battery has reached a critical temperature which can result in a critical failure</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/5/description</name>
    <message>
      <source>Battery temperature is below operating range</source>
      <translation type="unfinished">Battery temperature is below operating range</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/6/description</name>
    <message>
      <source>Voltage mismatch, use equally charged batteries</source>
      <translation type="unfinished">Voltage mismatch, use equally charged batteries</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/7/description</name>
    <message>
      <source>Battery firmware is not compatible with current autopilot firmware</source>
      <translation type="unfinished">Battery firmware is not compatible with current autopilot firmware</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/8/description</name>
    <message>
      <source>Battery model is not supported by the system</source>
      <translation type="unfinished">Battery model is not supported by the system</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/battery_fault_reason_t/entries/9/description</name>
    <message>
      <source>Battery reported an hardware problem</source>
      <translation type="unfinished">Battery reported an hardware problem</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/0/description</name>
    <message>
      <source>detected over current</source>
      <translation type="unfinished">detected over current</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/1/description</name>
    <message>
      <source>detected over voltage</source>
      <translation type="unfinished">detected over voltage</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/2/description</name>
    <message>
      <source>Motor has reached a critical temperature</source>
      <translation type="unfinished">Motor has reached a critical temperature</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/3/description</name>
    <message>
      <source>Motor RPM is exceeding the limits</source>
      <translation type="unfinished">Motor RPM is exceeding the limits</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/4/description</name>
    <message>
      <source>received an invalid control command</source>
      <translation type="unfinished">received an invalid control command</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/5/description</name>
    <message>
      <source>Motor stalled</source>
      <translation type="unfinished">Motor stalled</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/6/description</name>
    <message>
      <source>detected a generic hardware failure</source>
      <translation type="unfinished">detected a generic hardware failure</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/7/description</name>
    <message>
      <source>Motor is over-heating</source>
      <translation type="unfinished">Motor is over-heating</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/8/description</name>
    <message>
      <source>is over-heating</source>
      <translation type="unfinished">is over-heating</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/esc_fault_reason_t/entries/9/description</name>
    <message>
      <source>reached a critical temperature</source>
      <translation type="unfinished">reached a critical temperature</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/0/description</name>
    <message>
      <source/>
      <translation type="unfinished"/>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/1/description</name>
    <message>
      <source>warning</source>
      <translation type="unfinished">warning</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/10/description</name>
    <message>
      <source>terminate</source>
      <translation type="unfinished">terminate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/2/description</name>
    <message>
      <source>Position mode</source>
      <translation type="unfinished">Position mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/3/description</name>
    <message>
      <source>Altitude mode</source>
      <translation type="unfinished">Altitude mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/4/description</name>
    <message>
      <source>Stabilized mode</source>
      <translation type="unfinished">Stabilized mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/5/description</name>
    <message>
      <source>Hold</source>
      <translation type="unfinished">Hold</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/6/description</name>
    <message>
      <source>RTL</source>
      <translation type="unfinished">RTL</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/7/description</name>
    <message>
      <source>Land</source>
      <translation type="unfinished">Land</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/8/description</name>
    <message>
      <source>Descend</source>
      <translation type="unfinished">Descend</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_action_t/entries/9/description</name>
    <message>
      <source>disarm</source>
      <translation type="unfinished">disarm</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/0/description</name>
    <message>
      <source/>
      <translation type="unfinished"/>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/1/description</name>
    <message>
      <source>Manual control loss</source>
      <translation type="unfinished">Manual control loss</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/2/description</name>
    <message>
      <source>GCS connection loss</source>
      <translation type="unfinished">GCS connection loss</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/3/description</name>
    <message>
      <source>Low battery level</source>
      <translation type="unfinished">Low battery level</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/4/description</name>
    <message>
      <source>Critical battery level</source>
      <translation type="unfinished">Critical battery level</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/5/description</name>
    <message>
      <source>Emergency battery level</source>
      <translation type="unfinished">Emergency battery level</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/failsafe_cause_t/entries/6/description</name>
    <message>
      <source>Remaining flight time low</source>
      <translation type="unfinished">Remaining flight time low</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1/description</name>
    <message>
      <source>None</source>
      <translation type="unfinished">None</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1024/description</name>
    <message>
      <source>Logging</source>
      <translation type="unfinished">Logging</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1048576/description</name>
    <message>
      <source>System</source>
      <translation type="unfinished">System</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/1073741824/description</name>
    <message>
      <source>Open Drone ID system</source>
      <translation type="unfinished">Open Drone ID system</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/128/description</name>
    <message>
      <source>Remote Control (RC or Joystick)</source>
      <translation type="unfinished">Remote Control (RC or Joystick)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/131072/description</name>
    <message>
      <source>Local position estimate</source>
      <translation type="unfinished">Local position estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/134217728/description</name>
    <message>
      <source>Magnetometer</source>
      <translation type="unfinished">Magnetometer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/16/description</name>
    <message>
      <source>Optical flow</source>
      <translation>光流</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/16384/description</name>
    <message>
      <source>Attitude controller</source>
      <translation type="unfinished">Attitude controller</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/16777216/description</name>
    <message>
      <source>Global position estimate</source>
      <translation type="unfinished">Global position estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2/description</name>
    <message>
      <source>Absolute pressure</source>
      <translation type="unfinished">Absolute pressure</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2048/description</name>
    <message>
      <source>Battery</source>
      <translation type="unfinished">Battery</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2097152/description</name>
    <message>
      <source>Camera</source>
      <translation type="unfinished">Camera</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/2147483648/description</name>
    <message>
      <source>Traffic Avoidance (ADSB/FLARM)</source>
      <translation type="unfinished">Traffic Avoidance (ADSB/FLARM)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/256/description</name>
    <message>
      <source>Motors/ESCs</source>
      <translation type="unfinished">Motors/ESCs</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/262144/description</name>
    <message>
      <source>Mission</source>
      <translation type="unfinished">Mission</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/268435456/description</name>
    <message>
      <source>Accelerometer</source>
      <translation type="unfinished">Accelerometer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/32/description</name>
    <message>
      <source>Vision position estimate</source>
      <translation type="unfinished">Vision position estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/32768/description</name>
    <message>
      <source>Position controller</source>
      <translation type="unfinished">Position controller</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/33554432/description</name>
    <message>
      <source>Storage</source>
      <translation type="unfinished">Storage</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/4/description</name>
    <message>
      <source>Differential pressure</source>
      <translation type="unfinished">Differential pressure</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/4096/description</name>
    <message>
      <source>Communication links</source>
      <translation type="unfinished">Communication links</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/4194304/description</name>
    <message>
      <source>Gimbal</source>
      <translation type="unfinished">Gimbal</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/512/description</name>
    <message>
      <source>UTM</source>
      <translation type="unfinished">UTM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/524288/description</name>
    <message>
      <source>Avoidance</source>
      <translation type="unfinished">Avoidance</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/536870912/description</name>
    <message>
      <source>Gyroscope</source>
      <translation type="unfinished">Gyroscope</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/64/description</name>
    <message>
      <source>Distance sensor</source>
      <translation type="unfinished">Distance sensor</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/65536/description</name>
    <message>
      <source>Attitude estimate</source>
      <translation type="unfinished">Attitude estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/67108864/description</name>
    <message>
      <source>Parachute</source>
      <translation type="unfinished">Parachute</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/8/description</name>
    <message>
      <source>GPS</source>
      <translation type="unfinished">GPS</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/8192/description</name>
    <message>
      <source>Rate controller</source>
      <translation type="unfinished">Rate controller</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/health_component_t/entries/8388608/description</name>
    <message>
      <source>Payload</source>
      <translation type="unfinished">Payload</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1/description</name>
    <message>
      <source>Fully manual mode (w/o any controller support)</source>
      <translation type="unfinished">Fully manual mode (w/o any controller support)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1024/description</name>
    <message>
      <source>Acro</source>
      <translation type="unfinished">Acro</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1048576/description</name>
    <message>
      <source>Precision Land</source>
      <translation type="unfinished">Precision Land</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/1073741824/description</name>
    <message>
      <source>External 8</source>
      <translation type="unfinished">External 8</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/131072/description</name>
    <message>
      <source>Takeoff</source>
      <translation type="unfinished">Takeoff</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/134217728/description</name>
    <message>
      <source>External 5</source>
      <translation type="unfinished">External 5</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/16/description</name>
    <message>
      <source>Loiter</source>
      <translation type="unfinished">Loiter</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/16384/description</name>
    <message>
      <source>Offboard</source>
      <translation type="unfinished">Offboard</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/16777216/description</name>
    <message>
      <source>External 2</source>
      <translation type="unfinished">External 2</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/2/description</name>
    <message>
      <source>Altitude mode</source>
      <translation type="unfinished">Altitude mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/2097152/description</name>
    <message>
      <source>Orbit</source>
      <translation type="unfinished">Orbit</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/262144/description</name>
    <message>
      <source>Land</source>
      <translation type="unfinished">Land</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/268435456/description</name>
    <message>
      <source>External 6</source>
      <translation type="unfinished">External 6</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/32/description</name>
    <message>
      <source>RTL</source>
      <translation type="unfinished">RTL</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/32768/description</name>
    <message>
      <source>Stabilized</source>
      <translation type="unfinished">Stabilized</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/33554432/description</name>
    <message>
      <source>External 3</source>
      <translation type="unfinished">External 3</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/4/description</name>
    <message>
      <source>Position mode</source>
      <translation type="unfinished">Position mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/4194304/description</name>
    <message>
      <source>VTOL Takeoff</source>
      <translation type="unfinished">VTOL Takeoff</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/524288/description</name>
    <message>
      <source>Follow Target</source>
      <translation type="unfinished">Follow Target</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/536870912/description</name>
    <message>
      <source>External 7</source>
      <translation type="unfinished">External 7</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/67108864/description</name>
    <message>
      <source>External 4</source>
      <translation type="unfinished">External 4</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/8/description</name>
    <message>
      <source>Mission mode</source>
      <translation type="unfinished">Mission mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_group_t/entries/8388608/description</name>
    <message>
      <source>External 1</source>
      <translation type="unfinished">External 1</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/0/description</name>
    <message>
      <source>Manual</source>
      <translation type="unfinished">Manual</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/1/description</name>
    <message>
      <source>Altitude control</source>
      <translation type="unfinished">Altitude control</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/10/description</name>
    <message>
      <source>Takeoff</source>
      <translation type="unfinished">Takeoff</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/11/description</name>
    <message>
      <source>Land</source>
      <translation type="unfinished">Land</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/12/description</name>
    <message>
      <source>Follow Target</source>
      <translation type="unfinished">Follow Target</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/13/description</name>
    <message>
      <source>Precision Landing</source>
      <translation type="unfinished">Precision Landing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/14/description</name>
    <message>
      <source>Orbit</source>
      <translation type="unfinished">Orbit</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/15/description</name>
    <message>
      <source>Vtol Takeoff</source>
      <translation type="unfinished">Vtol Takeoff</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/16/description</name>
    <message>
      <source>External 1</source>
      <translation type="unfinished">External 1</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/17/description</name>
    <message>
      <source>External 2</source>
      <translation type="unfinished">External 2</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/18/description</name>
    <message>
      <source>External 3</source>
      <translation type="unfinished">External 3</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/19/description</name>
    <message>
      <source>External 4</source>
      <translation type="unfinished">External 4</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/2/description</name>
    <message>
      <source>Position control</source>
      <translation type="unfinished">Position control</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/20/description</name>
    <message>
      <source>External 5</source>
      <translation type="unfinished">External 5</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/21/description</name>
    <message>
      <source>External 6</source>
      <translation type="unfinished">External 6</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/22/description</name>
    <message>
      <source>External 7</source>
      <translation type="unfinished">External 7</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/23/description</name>
    <message>
      <source>External 8</source>
      <translation type="unfinished">External 8</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/24/description</name>
    <message>
      <source>Altitude Cruise</source>
      <translation type="unfinished">Altitude Cruise</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/255/description</name>
    <message>
      <source>[Unknown]</source>
      <translation type="unfinished">[Unknown]</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/3/description</name>
    <message>
      <source>Mission</source>
      <translation type="unfinished">Mission</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/4/description</name>
    <message>
      <source>Hold</source>
      <translation type="unfinished">Hold</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/5/description</name>
    <message>
      <source>RTL</source>
      <translation type="unfinished">RTL</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/6/description</name>
    <message>
      <source>Acro</source>
      <translation type="unfinished">Acro</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/7/description</name>
    <message>
      <source>Offboard</source>
      <translation type="unfinished">Offboard</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/8/description</name>
    <message>
      <source>Stabilized</source>
      <translation type="unfinished">Stabilized</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/navigation_mode_t/entries/9/description</name>
    <message>
      <source>Position Slow</source>
      <translation type="unfinished">Position Slow</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/1/description</name>
    <message>
      <source>No data</source>
      <translation type="unfinished">No data</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/16/description</name>
    <message>
      <source>High Error Density</source>
      <translation type="unfinished">High Error Density</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/2/description</name>
    <message>
      <source>Stale data</source>
      <translation type="unfinished">Stale data</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/4/description</name>
    <message>
      <source>Timeout</source>
      <translation type="unfinished">Timeout</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_failover_reason_t/entries/8/description</name>
    <message>
      <source>High Error Count</source>
      <translation type="unfinished">High Error Count</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_type_t/entries/0/description</name>
    <message>
      <source>Accelerometer</source>
      <translation type="unfinished">Accelerometer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_type_t/entries/1/description</name>
    <message>
      <source>Gyroscope</source>
      <translation type="unfinished">Gyroscope</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/sensor_type_t/entries/2/description</name>
    <message>
      <source>Magnetometer</source>
      <translation type="unfinished">Magnetometer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/suggested_action_t/entries/0/description</name>
    <message>
      <source/>
      <translation type="unfinished"/>
    </message>
  </context>
  <context>
    <name>/components/1/enums/suggested_action_t/entries/1/description</name>
    <message>
      <source>Land now!</source>
      <translation type="unfinished">Land now!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/enums/suggested_action_t/entries/2/description</name>
    <message>
      <source>Reduce throttle!</source>
      <translation type="unfinished">Reduce throttle!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10011251/message</name>
    <message>
      <source>Navigation error: No valid global position estimate</source>
      <translation type="unfinished">Navigation error: No valid global position estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10011251/description</name>
    <message>
      <source>The available positioning data is not sufficient to execute the selected mode.</source>
      <translation type="unfinished">The available positioning data is not sufficient to execute the selected mode.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10161216/message</name>
    <message>
      <source>Open Drone ID system missing</source>
      <translation type="unfinished">Open Drone ID system missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10161216/description</name>
    <message>
      <source>Open Drone ID system failed to report. Make sure it is setup and installed properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Open Drone ID system failed to report. Make sure it is setup and installed properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10198977/message</name>
    <message>
      <source>GPS PDOP too high</source>
      <translation type="unfinished">GPS PDOP too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10198977/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10450063/message</name>
    <message>
      <source>No valid attitude estimate</source>
      <translation type="unfinished">No valid attitude estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10450063/description</name>
    <message>
      <source>Wait until the estimator initialized</source>
      <translation type="unfinished">Wait until the estimator initialized</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1049276/message</name>
    <message>
      <source>GPS Horizontal Position Error too high</source>
      <translation type="unfinished">GPS Horizontal Position Error too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1049276/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10678671/message</name>
    <message>
      <source>GPS Speed Accuracy too low</source>
      <translation type="unfinished">GPS Speed Accuracy too low</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10678671/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10960133/message</name>
    <message>
      <source>Position estimate has low accuracy</source>
      <translation type="unfinished">Position estimate has low accuracy</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10960133/description</name>
    <message>
      <source>Local position estimate valid but has low accuracy. Warn user.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_POS_LOW_EPH&lt;/param&gt; and &lt;param&gt;COM_POS_LOW_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation type="unfinished">Local position estimate valid but has low accuracy. Warn user.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_POS_LOW_EPH&lt;/param&gt; and &lt;param&gt;COM_POS_LOW_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10996333/message</name>
    <message>
      <source>Missing FMU SD Card</source>
      <translation type="unfinished">Missing FMU SD Card</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/10996333/description</name>
    <message>
      <source>Insert an SD Card to the autopilot and reboot the system.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_SDCARD&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Insert an SD Card to the autopilot and reboot the system.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_SDCARD&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11047904/message</name>
    <message>
      <source>Arming check summary event</source>
      <translation type="unfinished">Arming check summary event</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11344647/message</name>
    <message>
      <source>Emergency battery level</source>
      <translation type="unfinished">Emergency battery level</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11344647/description</name>
    <message>
      <source>The lowest battery state of charge is below the emergency threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_EMERGEN_THR&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">The lowest battery state of charge is below the emergency threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_EMERGEN_THR&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11413600/message</name>
    <message>
      <source>Wind speed is above limit ({3:.1m/s})</source>
      <translation type="unfinished">Wind speed is above limit ({3:.1m/s})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11413600/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_WIND_MAX&lt;/param&gt; and &lt;param&gt;COM_WIND_MAX_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_WIND_MAX&lt;/param&gt; and &lt;param&gt;COM_WIND_MAX_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11497430/message</name>
    <message>
      <source>GPS Vertical Position Drift too high</source>
      <translation type="unfinished">GPS Vertical Position Drift too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/11497430/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12276004/message</name>
    <message>
      <source>Global position estimate required</source>
      <translation type="unfinished">Global position estimate required</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12276004/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; parameter.
&lt;/profile&gt; The available positioning data is not sufficient to determine the vehicle's global position.</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; parameter.
&lt;/profile&gt; The available positioning data is not sufficient to determine the vehicle's global position.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12369553/message</name>
    <message>
      <source>GPS fix too low</source>
      <translation type="unfinished">GPS fix too low</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12369553/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/124285/message</name>
    <message>
      <source>Geofence RTL requires valid home</source>
      <translation type="unfinished">Geofence RTL requires valid home</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/124285/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12689900/message</name>
    <message>
      <source>Navigation error: No valid altitude estimate</source>
      <translation type="unfinished">Navigation error: No valid altitude estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12689900/description</name>
    <message>
      <source>The available positioning data is not sufficient to execute the selected mode.</source>
      <translation type="unfinished">The available positioning data is not sufficient to execute the selected mode.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12754954/message</name>
    <message>
      <source>Flight termination active</source>
      <translation type="unfinished">Flight termination active</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12780289/message</name>
    <message>
      <source>GPS jamming detected</source>
      <translation type="unfinished">GPS jamming detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/12805643/message</name>
    <message>
      <source>Mission cannot be completed</source>
      <translation type="unfinished">Mission cannot be completed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13094458/message</name>
    <message>
      <source>Not enough GPS Satellites</source>
      <translation type="unfinished">Not enough GPS Satellites</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13094458/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1326449/message</name>
    <message>
      <source>Gyro {3} uncalibrated</source>
      <translation type="unfinished">Gyro {3} uncalibrated</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13528143/message</name>
    <message>
      <source>Vehicle is in transition state</source>
      <translation type="unfinished">Vehicle is in transition state</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13835193/message</name>
    <message>
      <source>Navigation error: No valid position estimate</source>
      <translation type="unfinished">Navigation error: No valid position estimate</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13835193/description</name>
    <message>
      <source>The available positioning data is not sufficient to execute the selected mode.</source>
      <translation type="unfinished">The available positioning data is not sufficient to execute the selected mode.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13923616/message</name>
    <message>
      <source>Geofence violation: exceeding maximum altitude above Home</source>
      <translation type="unfinished">Geofence violation: exceeding maximum altitude above Home</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/13923616/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; and &lt;param&gt;GF_MAX_VER_DIST&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; and &lt;param&gt;GF_MAX_VER_DIST&lt;/param&gt; parameters.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14200647/message</name>
    <message>
      <source>Vehicle is not in multicopter mode</source>
      <translation type="unfinished">Vehicle is not in multicopter mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14200647/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_VTOLARMING&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_VTOLARMING&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/143019/message</name>
    <message>
      <source>Geofence violation: approaching or outside geofence</source>
      <translation type="unfinished">Geofence violation: approaching or outside geofence</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/143019/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14644618/message</name>
    <message>
      <source>Maximum flight time reached</source>
      <translation type="unfinished">Maximum flight time reached</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14644618/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_FLT_TIME_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_FLT_TIME_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14748737/message</name>
    <message>
      <source>Mode is not registered</source>
      <translation type="unfinished">Mode is not registered</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14748737/description</name>
    <message>
      <source>The application running the mode is not started.</source>
      <translation type="unfinished">The application running the mode is not started.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14995448/message</name>
    <message>
      <source>GPS signal jammed</source>
      <translation type="unfinished">GPS signal jammed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/14995448/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/15180799/message</name>
    <message>
      <source>VTOL fixed-wing system failure detected. Verify reason for failure, and reboot the vehicle once confirmed safe</source>
      <translation type="unfinished">VTOL fixed-wing system failure detected. Verify reason for failure, and reboot the vehicle once confirmed safe</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/15713375/message</name>
    <message>
      <source>Strong magnetic interference</source>
      <translation type="unfinished">Strong magnetic interference</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/15713375/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Measured strength: {3:.3}, expected: {4:.3} ± &lt;param&gt;EKF2_MAG_CHK_STR&lt;/param&gt; Measured inclination: {5:.3}, expected: {6:.3} ± &lt;param&gt;EKF2_MAG_CHK_INC&lt;/param&gt; This check can be configured via &lt;param&gt;COM_ARM_MAG_STR&lt;/param&gt; and &lt;param&gt;EKF2_MAG_CHECK&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Measured strength: {3:.3}, expected: {4:.3} ± &lt;param&gt;EKF2_MAG_CHK_STR&lt;/param&gt; Measured inclination: {5:.3}, expected: {6:.3} ± &lt;param&gt;EKF2_MAG_CHK_INC&lt;/param&gt; This check can be configured via &lt;param&gt;COM_ARM_MAG_STR&lt;/param&gt; and &lt;param&gt;EKF2_MAG_CHECK&lt;/param&gt; parameters.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16158540/message</name>
    <message>
      <source>Landing gear switch set in UP position</source>
      <translation type="unfinished">Landing gear switch set in UP position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16642797/message</name>
    <message>
      <source>Heading estimate invalid</source>
      <translation type="unfinished">Heading estimate invalid</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16642797/description</name>
    <message>
      <source>Recalibrate compass or perform manual heading reset.</source>
      <translation type="unfinished">Recalibrate compass or perform manual heading reset.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16716537/message</name>
    <message>
      <source>Compass {3} uncalibrated</source>
      <translation type="unfinished">Compass {3} uncalibrated</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16745468/message</name>
    <message>
      <source>Attitude failure detected</source>
      <translation type="unfinished">Attitude failure detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/16745468/description</name>
    <message>
      <source>The vehicle exceeded the maximum configured pitch angle.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_FAIL_P&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The vehicle exceeded the maximum configured pitch angle.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_FAIL_P&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1802995/message</name>
    <message>
      <source>Airspeed too high</source>
      <translation type="unfinished">Airspeed too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1802995/description</name>
    <message>
      <source>Current airspeed reading too high. Check if wind is below maximum airspeed and redo airspeed calibration if the measured airspeed does not correspond to wind conditions.

&lt;profile name="dev"&gt; Measured: {3:.1m/s}, limit: {4:.1m/s}.

This check can be configured via &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Current airspeed reading too high. Check if wind is below maximum airspeed and redo airspeed calibration if the measured airspeed does not correspond to wind conditions.

&lt;profile name="dev"&gt; Measured: {3:.1m/s}, limit: {4:.1m/s}.

This check can be configured via &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1871713/message</name>
    <message>
      <source>Mode not suitable for arming</source>
      <translation type="unfinished">Mode not suitable for arming</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1871713/description</name>
    <message>
      <source>Switch to another mode first.</source>
      <translation type="unfinished">Switch to another mode first.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1917030/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: TRIM greater than MAX ({4} greater than {5})</source>
      <translation type="unfinished">RC calibration for channel {3} invalid: TRIM greater than MAX ({4} greater than {5})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/1917030/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation type="unfinished">Recalibrate the RC.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2088119/message</name>
    <message>
      <source>Poor GPS Quality</source>
      <translation type="unfinished">Poor GPS Quality</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2228586/message</name>
    <message>
      <source>Remaining flight time low</source>
      <translation type="unfinished">Remaining flight time low</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2229864/message</name>
    <message>
      <source>Power redundancy not met</source>
      <translation type="unfinished">Power redundancy not met</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2229864/description</name>
    <message>
      <source>Available power modules: {3}. Required power modules: {4}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_POWER_COUNT&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Available power modules: {3}. Required power modules: {4}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_POWER_COUNT&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2481841/message</name>
    <message>
      <source>Gyro {3} inconsistent</source>
      <translation type="unfinished">Gyro {3} inconsistent</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2481841/description</name>
    <message>
      <source>Check the calibration.

Inconsistency value: {4}. Configured Threshold: {5}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_IMU_GYR&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Check the calibration.

Inconsistency value: {4}. Configured Threshold: {5}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_IMU_GYR&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2627595/message</name>
    <message>
      <source>Critical battery</source>
      <translation type="unfinished">Critical battery</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/2627595/description</name>
    <message>
      <source>The lowest battery state of charge is below the critical threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_CRIT_THR&lt;/param&gt; and from when to disalow arming with &lt;param&gt;COM_ARM_BAT_MIN&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">The lowest battery state of charge is below the critical threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_CRIT_THR&lt;/param&gt; and from when to disalow arming with &lt;param&gt;COM_ARM_BAT_MIN&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/276785/message</name>
    <message>
      <source>Press safety button first</source>
      <translation type="unfinished">Press safety button first</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/276785/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_IO_SAFETY&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_IO_SAFETY&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3061044/message</name>
    <message>
      <source>Accel {3} inconsistent</source>
      <translation type="unfinished">Accel {3} inconsistent</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3061044/description</name>
    <message>
      <source>Check the calibration.

Inconsistency value: {4}. Configured Threshold: {5}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_IMU_ACC&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Check the calibration.

Inconsistency value: {4}. Configured Threshold: {5}.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_IMU_ACC&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3087815/message</name>
    <message>
      <source>No offboard signal</source>
      <translation type="unfinished">No offboard signal</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3087815/description</name>
    <message>
      <source>The offboard component is not sending setpoints or the required estimate (e.g. position) is missing.</source>
      <translation type="unfinished">The offboard component is not sending setpoints or the required estimate (e.g. position) is missing.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3603209/message</name>
    <message>
      <source>Stopping compass use</source>
      <translation type="unfinished">Stopping compass use</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3603209/description</name>
    <message>
      <source>Land and calibrate the compass.</source>
      <translation type="unfinished">Land and calibrate the compass.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3613628/message</name>
    <message>
      <source>High Accelerometer Bias</source>
      <translation type="unfinished">High Accelerometer Bias</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/3613628/description</name>
    <message>
      <source>An accelerometer recalibration might help.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

This check can be configured via &lt;param&gt;EKF2_ABL_LIM&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">An accelerometer recalibration might help.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

This check can be configured via &lt;param&gt;EKF2_ABL_LIM&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/377561/message</name>
    <message>
      <source>No valid mission available</source>
      <translation type="unfinished">No valid mission available</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/377561/description</name>
    <message>
      <source>Upload a mission first.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_MIS_REQ&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Upload a mission first.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_MIS_REQ&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4065583/message</name>
    <message>
      <source>Geofence violation: exceeding maximum distance to Home</source>
      <translation type="unfinished">Geofence violation: exceeding maximum distance to Home</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4065583/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; and &lt;param&gt;GF_MAX_HOR_DIST&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;GF_ACTION&lt;/param&gt; and &lt;param&gt;GF_MAX_HOR_DIST&lt;/param&gt; parameters.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4261821/message</name>
    <message>
      <source>Failure triggered by external system</source>
      <translation type="unfinished">Failure triggered by external system</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4261821/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_EXT_ATS_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_EXT_ATS_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/453929/message</name>
    <message>
      <source>No manual control input</source>
      <translation type="unfinished">No manual control input</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/453929/description</name>
    <message>
      <source>Connect and enable stick input or use autonomous mode.
&lt;profile name="dev"&gt; Sticks can be enabled via &lt;param&gt;COM_RC_IN_MODE&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Connect and enable stick input or use autonomous mode.
&lt;profile name="dev"&gt; Sticks can be enabled via &lt;param&gt;COM_RC_IN_MODE&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4549029/message</name>
    <message>
      <source>Altitude failure detected</source>
      <translation type="unfinished">Altitude failure detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4554738/message</name>
    <message>
      <source>No rally point available</source>
      <translation type="unfinished">No rally point available</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4554738/description</name>
    <message>
      <source>Upload at least one rally point before arming, or change &lt;param&gt;RTL_TYPE&lt;/param&gt;.

&lt;profile name="dev"&gt; This check is active when RTL_TYPE is set to 5 (safe points only).
&lt;/profile&gt;</source>
      <translation type="unfinished">Upload at least one rally point before arming, or change &lt;param&gt;RTL_TYPE&lt;/param&gt;.

&lt;profile name="dev"&gt; This check is active when RTL_TYPE is set to 5 (safe points only).
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4975227/message</name>
    <message>
      <source>GPS Horizontal Speed Drift too high</source>
      <translation type="unfinished">GPS Horizontal Speed Drift too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/4975227/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5049764/message</name>
    <message>
      <source>Low battery</source>
      <translation type="unfinished">Low battery</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5049764/description</name>
    <message>
      <source>The lowest battery state of charge is below the low threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_LOW_THR&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">The lowest battery state of charge is below the low threshold.

&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;BAT_LOW_THR&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/516062/message</name>
    <message>
      <source>GPS Vertical Position Error too high</source>
      <translation type="unfinished">GPS Vertical Position Error too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/516062/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5273740/message</name>
    <message>
      <source>Compass inconsistent by {3} degrees</source>
      <translation type="unfinished">Compass inconsistent by {3} degrees</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5273740/description</name>
    <message>
      <source>Check the compass orientations and recalibrate.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_MAG_ANG&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Check the compass orientations and recalibrate.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_MAG_ANG&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5444856/message</name>
    <message>
      <source>Accelerometer {3} uncalibrated</source>
      <translation type="unfinished">Accelerometer {3} uncalibrated</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5704353/message</name>
    <message>
      <source>Arm authorization denied</source>
      <translation type="unfinished">Arm authorization denied</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5717196/message</name>
    <message>
      <source>GPS Horizontal Position Drift too high</source>
      <translation type="unfinished">GPS Horizontal Position Drift too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5717196/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5943233/message</name>
    <message>
      <source>Found {3} compass (required: {4})</source>
      <translation type="unfinished">Found {3} compass (required: {4})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/5943233/description</name>
    <message>
      <source>Make sure all required sensors are working, enabled and calibrated.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_MAG&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Make sure all required sensors are working, enabled and calibrated.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_MAG&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6054338/message</name>
    <message>
      <source>Waiting for estimator to initialize</source>
      <translation type="unfinished">Waiting for estimator to initialize</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6258044/message</name>
    <message>
      <source>Estimator fault due to Compass {3}</source>
      <translation type="unfinished">Estimator fault due to Compass {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6258044/description</name>
    <message>
      <source>Recalibrate the compass and check the orientation.</source>
      <translation type="unfinished">Recalibrate the compass and check the orientation.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6491364/message</name>
    <message>
      <source>Home position required</source>
      <translation type="unfinished">Home position required</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6491364/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6558257/message</name>
    <message>
      <source>GPS Vertical Speed Drift too high</source>
      <translation type="unfinished">GPS Vertical Speed Drift too high</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6558257/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6801787/message</name>
    <message>
      <source>No connection to the ground control station</source>
      <translation type="unfinished">No connection to the ground control station</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6801787/description</name>
    <message>
      <source>To arm, at least a data link or RC must be present.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;NAV_DLL_ACT&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">To arm, at least a data link or RC must be present.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;NAV_DLL_ACT&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6979701/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: MIN less than {4}</source>
      <translation type="unfinished">RC calibration for channel {3} invalid: MIN less than {4}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/6979701/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation type="unfinished">Recalibrate the RC.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7662152/message</name>
    <message>
      <source>USB connected</source>
      <translation type="unfinished">USB connected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7662152/description</name>
    <message>
      <source>Flying with USB is not safe. Disconnect it and reboot the FMU.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_USB_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Flying with USB is not safe. Disconnect it and reboot the FMU.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_USB_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7847312/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: MAX greater than {4}</source>
      <translation type="unfinished">RC calibration for channel {3} invalid: MAX greater than {4}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7847312/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation type="unfinished">Recalibrate the RC.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7884377/message</name>
    <message>
      <source>RTL switch engaged</source>
      <translation type="unfinished">RTL switch engaged</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/79408/message</name>
    <message>
      <source>Home position not set</source>
      <translation type="unfinished">Home position not set</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7959667/message</name>
    <message>
      <source>Vehicle is in safety configuration</source>
      <translation type="unfinished">Vehicle is in safety configuration</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/7959667/description</name>
    <message>
      <source>Vehicle is in safety configuration and denies arming.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARMABLE&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Vehicle is in safety configuration and denies arming.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARMABLE&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/810921/message</name>
    <message>
      <source>Waypoint above maximum height</source>
      <translation type="unfinished">Waypoint above maximum height</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8441780/message</name>
    <message>
      <source>Open Drone ID system not ready</source>
      <translation type="unfinished">Open Drone ID system not ready</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8441780/description</name>
    <message>
      <source>Open Drone ID system reported being unhealthy.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Open Drone ID system reported being unhealthy.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_ODID&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8495477/message</name>
    <message>
      <source>RC calibration for channel {3} invalid: TRIM less than MIN ({4} less than {5})</source>
      <translation type="unfinished">RC calibration for channel {3} invalid: TRIM less than MIN ({4} less than {5})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8495477/description</name>
    <message>
      <source>Recalibrate the RC.</source>
      <translation type="unfinished">Recalibrate the RC.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8538897/message</name>
    <message>
      <source>Attitude failure detected</source>
      <translation type="unfinished">Attitude failure detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8538897/description</name>
    <message>
      <source>The vehicle exceeded the maximum configured roll angle.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_FAIL_R&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The vehicle exceeded the maximum configured roll angle.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_FAIL_R&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8713942/message</name>
    <message>
      <source>GPS signal spoofed</source>
      <translation type="unfinished">GPS signal spoofed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8713942/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Can be configured with &lt;param&gt;EKF2_GPS_CHECK&lt;/param&gt; and &lt;param&gt;COM_ARM_WO_GPS&lt;/param&gt;.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/8902208/message</name>
    <message>
      <source>Horizontal velocity unstable</source>
      <translation type="unfinished">Horizontal velocity unstable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9077977/message</name>
    <message>
      <source>Kill switch engaged</source>
      <translation type="unfinished">Kill switch engaged</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9134139/message</name>
    <message>
      <source>Traffic avoidance system missing</source>
      <translation type="unfinished">Traffic avoidance system missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9134139/description</name>
    <message>
      <source>Traffic avoidance system (ADSB/FLARM) failed to report. Make sure it is setup and connected properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_TRAFF&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Traffic avoidance system (ADSB/FLARM) failed to report. Make sure it is setup and connected properly.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_TRAFF&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9171208/message</name>
    <message>
      <source>Vertical velocity unstable</source>
      <translation type="unfinished">Vertical velocity unstable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9307221/message</name>
    <message>
      <source>High Gyro Bias</source>
      <translation type="unfinished">High Gyro Bias</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9307221/description</name>
    <message>
      <source>A Gyro recalibration might help.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

This check can be configured via &lt;param&gt;EKF2_ABL_GYRLIM&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">A Gyro recalibration might help.

&lt;profile name="dev"&gt; Axis {3}: |{4:.8}| \&gt; {5:.8} + {6:.8}

This check can be configured via &lt;param&gt;EKF2_ABL_GYRLIM&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9608226/message</name>
    <message>
      <source>Estimator not using GPS</source>
      <translation type="unfinished">Estimator not using GPS</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9634798/message</name>
    <message>
      <source>Height estimate not stable</source>
      <translation type="unfinished">Height estimate not stable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9643369/message</name>
    <message>
      <source>Angular velocity not valid</source>
      <translation type="unfinished">Angular velocity not valid</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9643369/description</name>
    <message>
      <source>Make sure the gyroscope is providing valid data.</source>
      <translation type="unfinished">Make sure the gyroscope is providing valid data.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9697819/message</name>
    <message>
      <source>Horizontal position unstable</source>
      <translation type="unfinished">Horizontal position unstable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9815168/message</name>
    <message>
      <source>Mode is unresponsive</source>
      <translation type="unfinished">Mode is unresponsive</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9815168/description</name>
    <message>
      <source>The application running the mode might have crashed or the CPU load is too high.</source>
      <translation type="unfinished">The application running the mode might have crashed or the CPU load is too high.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9965819/message</name>
    <message>
      <source>GNSS heading not reliable</source>
      <translation type="unfinished">GNSS heading not reliable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/arming_check/events/9965819/description</name>
    <message>
      <source>Land now</source>
      <translation type="unfinished">Land now</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10044444/message</name>
    <message>
      <source>Error loading settings</source>
      <translation type="unfinished">Error loading settings</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10072599/message</name>
    <message>
      <source>Calibration: Disabling RC input</source>
      <translation type="unfinished">Calibration: Disabling RC input</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10155243/message</name>
    <message>
      <source>Unsupported base mode</source>
      <translation type="unfinished">Unsupported base mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10162376/message</name>
    <message>
      <source>Mission land item could not be read</source>
      <translation type="unfinished">Mission land item could not be read</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10229254/message</name>
    <message>
      <source>RTL Mission Land: climb to {1m_v}</source>
      <translation type="unfinished">RTL Mission Land: climb to {1m_v}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10236960/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}</source>
      <translation type="unfinished">Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10236960/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation type="unfinished">- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10250020/message</name>
    <message>
      <source>CA_SV_CS{1}_TRIM ({2}) is reset to 0 as PWM CENTER is used</source>
      <translation type="unfinished">CA_SV_CS{1}_TRIM ({2}) is reset to 0 as PWM CENTER is used</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10250020/description</name>
    <message>
      <source>Display warning in GCS when TRIM settings were present and now CENTER are set.</source>
      <translation type="unfinished">Display warning in GCS when TRIM settings were present and now CENTER are set.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10384464/message</name>
    <message>
      <source>Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</source>
      <translation type="unfinished">Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10452355/message</name>
    <message>
      <source>Takeoff airspeed reached, climbout</source>
      <translation type="unfinished">Takeoff airspeed reached, climbout</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1047676/message</name>
    <message>
      <source>Enabling transmitting with IRIDIUM mavlink on instance {1} by command</source>
      <translation type="unfinished">Enabling transmitting with IRIDIUM mavlink on instance {1} by command</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10493596/message</name>
    <message>
      <source>Airspeed sensor failure detected. Return to launch (RTL) is advised</source>
      <translation type="unfinished">Airspeed sensor failure detected. Return to launch (RTL) is advised</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10503063/message</name>
    <message>
      <source>Switching to mode '{2}' is currently not possible</source>
      <translation type="unfinished">Switching to mode '{2}' is currently not possible</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10600202/message</name>
    <message>
      <source>Arming denied: throttle not in safe position</source>
      <translation type="unfinished">Arming denied: throttle not in safe position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10658115/message</name>
    <message>
      <source>SET_POSITION_TARGET_GLOBAL_INT: FORCE is not supported</source>
      <translation type="unfinished">SET_POSITION_TARGET_GLOBAL_INT: FORCE is not supported</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10664053/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, returning home</source>
      <translation type="unfinished">Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, returning home</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10664053/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation type="unfinished">- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10716939/message</name>
    <message>
      <source>Onboard controller regained</source>
      <translation type="unfinished">Onboard controller regained</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10794072/message</name>
    <message>
      <source>Connection to ground control station lost</source>
      <translation type="unfinished">Connection to ground control station lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10834203/message</name>
    <message>
      <source>Enabling transmitting with IRIDIUM mavlink on instance {1}</source>
      <translation type="unfinished">Enabling transmitting with IRIDIUM mavlink on instance {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10962739/message</name>
    <message>
      <source>SET_POSITION_TARGET_GLOBAL_INT invalid coordinate frame {1}</source>
      <translation type="unfinished">SET_POSITION_TARGET_GLOBAL_INT invalid coordinate frame {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/10973461/message</name>
    <message>
      <source>Geofence invalid, doesn't contain Home position</source>
      <translation type="unfinished">Geofence invalid, doesn't contain Home position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11085221/message</name>
    <message>
      <source>Mission: unable to write to storage</source>
      <translation type="unfinished">Mission: unable to write to storage</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11123101/message</name>
    <message>
      <source>Connection to mission computer lost</source>
      <translation type="unfinished">Connection to mission computer lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1119664/message</name>
    <message>
      <source>Invalid configuration: FW_AIRSPD_STALL higher FW_AIRSPD_MIN</source>
      <translation type="unfinished">Invalid configuration: FW_AIRSPD_STALL higher FW_AIRSPD_MIN</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1119664/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_STALL&lt;/param&gt;: {2:.1}</source>
      <translation type="unfinished">- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_STALL&lt;/param&gt;: {2:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11290563/message</name>
    <message>
      <source>Kill engaged</source>
      <translation type="unfinished">Kill engaged</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11521721/message</name>
    <message>
      <source>Mission rejected: Mission contains VTOL items but vehicle is not a VTOL</source>
      <translation type="unfinished">Mission rejected: Mission contains VTOL items but vehicle is not a VTOL</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11552065/message</name>
    <message>
      <source>SET_POSITION_TARGET_LOCAL_NED: coordinate frame {1} unsupported</source>
      <translation type="unfinished">SET_POSITION_TARGET_LOCAL_NED: coordinate frame {1} unsupported</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11572261/message</name>
    <message>
      <source>Reduce the glide slope, lower the entrance altitude {1} meters, or increase the landing approach distance {2} meters</source>
      <translation type="unfinished">Reduce the glide slope, lower the entrance altitude {1} meters, or increase the landing approach distance {2} meters</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11606074/message</name>
    <message>
      <source>Launch detected: enable motors (no motor delay)</source>
      <translation type="unfinished">Launch detected: enable motors (no motor delay)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11664376/message</name>
    <message>
      <source>Mission: Unable to read from storage</source>
      <translation type="unfinished">Mission: Unable to read from storage</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11664376/description</name>
    <message>
      <source>Mission type: {1}</source>
      <translation type="unfinished">Mission type: {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11724756/message</name>
    <message>
      <source>Waypoint {1} could not be read from storage</source>
      <translation type="unfinished">Waypoint {1} could not be read from storage</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/11985219/message</name>
    <message>
      <source>Holding at {1:.0m_v} above landing waypoint</source>
      <translation type="unfinished">Holding at {1:.0m_v} above landing waypoint</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1203183/message</name>
    <message>
      <source>logging: opening log file {1}-{2}-{3}/{4}_{5}_{6}.ulg</source>
      <translation type="unfinished">logging: opening log file {1}-{2}-{3}/{4}_{5}_{6}.ulg</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12140426/message</name>
    <message>
      <source>EKF2_MAG_TYPE invalid, resetting to default</source>
      <translation type="unfinished">EKF2_MAG_TYPE invalid, resetting to default</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12140426/description</name>
    <message>
      <source>&lt;param&gt;EKF2_MAG_TYPE&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;EKF2_MAG_TYPE&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12208749/message</name>
    <message>
      <source>Mission rejected: takeoff altitude too low! Minimum: {1:.1m_v}</source>
      <translation type="unfinished">Mission rejected: takeoff altitude too low! Minimum: {1:.1m_v}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12216659/message</name>
    <message>
      <source>Low battery level, return advised</source>
      <translation type="unfinished">Low battery level, return advised</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12221094/message</name>
    <message>
      <source>Landing target: unsupported coordinate frame {1}</source>
      <translation type="unfinished">Landing target: unsupported coordinate frame {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12224414/message</name>
    <message>
      <source>Mission rejected: Takeoff or Landing item missing</source>
      <translation type="unfinished">Mission rejected: Takeoff or Landing item missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/122461/message</name>
    <message>
      <source>Landing aborted: terrain measurement not found</source>
      <translation>降落中断：无地形测量结果</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12306507/message</name>
    <message>
      <source>Target altitude higher than max HAGL</source>
      <translation type="unfinished">Target altitude higher than max HAGL</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12320347/message</name>
    <message>
      <source>Primary airspeed index bigger than number connected sensors, taking last sensor</source>
      <translation type="unfinished">Primary airspeed index bigger than number connected sensors, taking last sensor</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12420351/message</name>
    <message>
      <source>Arming denied: switch to manual mode first</source>
      <translation type="unfinished">Arming denied: switch to manual mode first</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12464476/message</name>
    <message>
      <source>Ready for throw launch</source>
      <translation type="unfinished">Ready for throw launch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12472677/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_SPEED_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_SPEED_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12499622/message</name>
    <message>
      <source>Mission: Unable to write to storage</source>
      <translation type="unfinished">Mission: Unable to write to storage</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12500025/message</name>
    <message>
      <source>Mission: Unable to write to storage</source>
      <translation type="unfinished">Mission: Unable to write to storage</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12621639/message</name>
    <message>
      <source>Remote ID system lost</source>
      <translation type="unfinished">Remote ID system lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12768213/message</name>
    <message>
      <source>Mission rejected: more than one land start commands</source>
      <translation type="unfinished">Mission rejected: more than one land start commands</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12770418/message</name>
    <message>
      <source>Failsafe activated: Autopilot disengaged, switching to {2}</source>
      <translation type="unfinished">Failsafe activated: Autopilot disengaged, switching to {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12770418/description</name>
    <message>
      <source>Failsafe actions that disengage the autopilot (remove position control)</source>
      <translation type="unfinished">Failsafe actions that disengage the autopilot (remove position control)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12815955/message</name>
    <message>
      <source>SET_POSITION_TARGET_LOCAL_NED: FORCE is not supported</source>
      <translation type="unfinished">SET_POSITION_TARGET_LOCAL_NED: FORCE is not supported</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12894058/message</name>
    <message>
      <source>{1} sensor #{2} failure: {3}</source>
      <translation type="unfinished">{1} sensor #{2} failure: {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12894058/description</name>
    <message>
      <source>Land immediately and check the system.</source>
      <translation type="unfinished">Land immediately and check the system.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12957883/message</name>
    <message>
      <source>Start descending</source>
      <translation type="unfinished">Start descending</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/12987489/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_P</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_P</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13168253/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RA_WHEEL_BASE</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RA_WHEEL_BASE</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13277401/message</name>
    <message>
      <source>Failsafe warning:</source>
      <translation type="unfinished">Failsafe warning:</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13277401/description</name>
    <message>
      <source>No action is triggered.</source>
      <translation type="unfinished">No action is triggered.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/133277/message</name>
    <message>
      <source>Arming denied: Resolve system health failures first</source>
      <translation type="unfinished">Arming denied: Resolve system health failures first</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13378512/message</name>
    <message>
      <source>Distance between waypoint and gate too close: {1:.3m} (minimum: {2:.3m})</source>
      <translation type="unfinished">Distance between waypoint and gate too close: {1:.3m} (minimum: {2:.3m})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13440627/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_MAX_THR_SPEED</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_MAX_THR_SPEED</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13471314/message</name>
    <message>
      <source>Quad-chute triggered due to loss of altitude during transition</source>
      <translation type="unfinished">Quad-chute triggered due to loss of altitude during transition</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13495236/message</name>
    <message>
      <source>Reposition is outside geofence</source>
      <translation type="unfinished">Reposition is outside geofence</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1351736/message</name>
    <message>
      <source>Traffic avoidance system regained</source>
      <translation type="unfinished">Traffic avoidance system regained</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13568553/message</name>
    <message>
      <source>New mission waypoint sequence out of bounds</source>
      <translation type="unfinished">New mission waypoint sequence out of bounds</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13612093/message</name>
    <message>
      <source>Traffic avoidance system lost</source>
      <translation type="unfinished">Traffic avoidance system lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1369685/message</name>
    <message>
      <source>Takeoff on runway</source>
      <translation type="unfinished">Takeoff on runway</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13704694/message</name>
    <message>
      <source>{4}: switching to {2} in {3} seconds</source>
      <translation type="unfinished">{4}: switching to {2} in {3} seconds</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13944665/message</name>
    <message>
      <source>Transition to hover mode and descend</source>
      <translation type="unfinished">Transition to hover mode and descend</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/13956202/message</name>
    <message>
      <source>Mission rejected: invalid land start</source>
      <translation type="unfinished">Mission rejected: invalid land start</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14080694/message</name>
    <message>
      <source>Descent speed has been constrained by max speed</source>
      <translation type="unfinished">Descent speed has been constrained by max speed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14080694/description</name>
    <message>
      <source>&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_Z_V_AUTO_DN&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1410140/message</name>
    <message>
      <source>Quad-chute triggered due to external command</source>
      <translation type="unfinished">Quad-chute triggered due to external command</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14117485/message</name>
    <message>
      <source>EKF2_DELAY_MAX increased to {2}ms, please reboot</source>
      <translation type="unfinished">EKF2_DELAY_MAX increased to {2}ms, please reboot</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14117485/description</name>
    <message>
      <source>EKF2_DELAY_MAX({1}ms) is too small compared to the maximum sensor delay ({2})</source>
      <translation type="unfinished">EKF2_DELAY_MAX({1}ms) is too small compared to the maximum sensor delay ({2})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14153224/message</name>
    <message>
      <source>Manual speed has been constrained by maximum speed</source>
      <translation type="unfinished">Manual speed has been constrained by maximum speed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14153224/description</name>
    <message>
      <source>&lt;param&gt;MPC_VEL_MANUAL&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_VEL_MANUAL&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14234660/message</name>
    <message>
      <source>GCS connection regained</source>
      <translation type="unfinished">GCS connection regained</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14440680/message</name>
    <message>
      <source>Mission sync timeout, aborting transfer</source>
      <translation type="unfinished">Mission sync timeout, aborting transfer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14443523/message</name>
    <message>
      <source>Launch detected: enable motors</source>
      <translation type="unfinished">Launch detected: enable motors</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14535820/message</name>
    <message>
      <source>Landing aborted: terrain estimate timed out</source>
      <translation>降落中断：地形估算超时</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14581325/message</name>
    <message>
      <source>Maximum tilt limit has been constrained to a safe value</source>
      <translation type="unfinished">Maximum tilt limit has been constrained to a safe value</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14581325/description</name>
    <message>
      <source>&lt;param&gt;MPC_TILTMAX_AIR&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_TILTMAX_AIR&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14605264/message</name>
    <message>
      <source>Failsafe activated: switching to {2}</source>
      <translation type="unfinished">Failsafe activated: switching to {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/14699175/message</name>
    <message>
      <source>GNSS data fusion stopped</source>
      <translation type="unfinished">GNSS data fusion stopped</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15098248/message</name>
    <message>
      <source>Disabling transmitting with IRIDIUM mavlink on instance {1}</source>
      <translation type="unfinished">Disabling transmitting with IRIDIUM mavlink on instance {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1525547/message</name>
    <message>
      <source>Landing aborted: unknown criterion</source>
      <translation>着陆中止：原因不明</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15283212/message</name>
    <message>
      <source>Mission download request ignored, already active</source>
      <translation type="unfinished">Mission download request ignored, already active</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15292483/message</name>
    <message>
      <source>GNSS data fusion started</source>
      <translation type="unfinished">GNSS data fusion started</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15317431/message</name>
    <message>
      <source>Invalid configuration: Airspeed max \&lt; 5 m/s or min \&gt; 100 m/s</source>
      <translation type="unfinished">Invalid configuration: Airspeed max \&lt; 5 m/s or min \&gt; 100 m/s</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15317431/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</source>
      <translation type="unfinished">- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15373867/message</name>
    <message>
      <source>Launch detected: enablecontrol, waiting {1:.1}s until full throttle</source>
      <translation type="unfinished">Launch detected: enablecontrol, waiting {1:.1}s until full throttle</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15438771/message</name>
    <message>
      <source>Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</source>
      <translation type="unfinished">Invalid configuration for speed control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_SPEED_P) is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15456613/message</name>
    <message>
      <source>Accel {1} clipping, not safe to fly!</source>
      <translation type="unfinished">Accel {1} clipping, not safe to fly!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15456613/description</name>
    <message>
      <source>Land now, and check the vehicle setup. Clipping can lead to fly-aways.</source>
      <translation type="unfinished">Land now, and check the vehicle setup. Clipping can lead to fly-aways.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15499150/message</name>
    <message>
      <source>Autotune axis selection not supported through Mission. Use FW_AT_AXES to set axes for fixed-wing vehicles</source>
      <translation type="unfinished">Autotune axis selection not supported through Mission. Use FW_AT_AXES to set axes for fixed-wing vehicles</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15536452/message</name>
    <message>
      <source>External mode is unresponsive, falling back to internal</source>
      <translation type="unfinished">External mode is unresponsive, falling back to internal</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15598001/message</name>
    <message>
      <source>Executing Mission</source>
      <translation type="unfinished">Executing Mission</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15603271/message</name>
    <message>
      <source>Dangerously low battery! Shutting system down</source>
      <translation type="unfinished">Dangerously low battery! Shutting system down</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15624514/message</name>
    <message>
      <source>Wind speed above limit ({1:.1m/s}), landing advised</source>
      <translation type="unfinished">Wind speed above limit ({1:.1m/s}), landing advised</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1569033/message</name>
    <message>
      <source>parameter_rc_channel_index out of bounds</source>
      <translation type="unfinished">parameter_rc_channel_index out of bounds</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15869512/message</name>
    <message>
      <source>Quad-chute triggered due to transition timeout</source>
      <translation type="unfinished">Quad-chute triggered due to transition timeout</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15900704/message</name>
    <message>
      <source>Quad-chute triggered due to minimum altitude breach</source>
      <translation type="unfinished">Quad-chute triggered due to minimum altitude breach</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15909593/message</name>
    <message>
      <source>Cruise speed has been constrained by maximum speed</source>
      <translation type="unfinished">Cruise speed has been constrained by maximum speed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/15909593/description</name>
    <message>
      <source>&lt;param&gt;MPC_XY_CRUISE&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_XY_CRUISE&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1593841/message</name>
    <message>
      <source>Too much traffic! Showing all messages from now on</source>
      <translation type="unfinished">Too much traffic! Showing all messages from now on</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16017271/message</name>
    <message>
      <source>Disarmed by {1}</source>
      <translation type="unfinished">Disarmed by {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1604295/message</name>
    <message>
      <source>Terrain collision risk, descent is stopped</source>
      <translation type="unfinished">Terrain collision risk, descent is stopped</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16048801/message</name>
    <message>
      <source>Not logging, storage is almost full: {1} MiB</source>
      <translation type="unfinished">Not logging, storage is almost full: {1} MiB</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16048801/description</name>
    <message>
      <source>Either manually free up some space, or enable automatic log rotation via &lt;param&gt;SDLOG_DIRS_MAX&lt;/param&gt;.</source>
      <translation type="unfinished">Either manually free up some space, or enable automatic log rotation via &lt;param&gt;SDLOG_DIRS_MAX&lt;/param&gt;.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16223078/message</name>
    <message>
      <source>Landing aborted by operator</source>
      <translation>操作员终止着陆</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16329867/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_RATE_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_RATE_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16347639/message</name>
    <message>
      <source>Landing, flaring</source>
      <translation type="unfinished">Landing, flaring</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16440365/message</name>
    <message>
      <source>ODOMETRY: unsupported estimator_type {1}</source>
      <translation type="unfinished">ODOMETRY: unsupported estimator_type {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16509566/message</name>
    <message>
      <source>Mission rejected: Add Takeoff item or remove Landing</source>
      <translation type="unfinished">Mission rejected: Add Takeoff item or remove Landing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16558486/message</name>
    <message>
      <source>Disarmed, don't throw</source>
      <translation type="unfinished">Disarmed, don't throw</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16591495/message</name>
    <message>
      <source>Control high latency failed! Telemetry unavailable</source>
      <translation type="unfinished">Control high latency failed! Telemetry unavailable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16663074/message</name>
    <message>
      <source>Mission rejected: takeoff is not the first waypoint item</source>
      <translation type="unfinished">Mission rejected: takeoff is not the first waypoint item</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16682655/message</name>
    <message>
      <source>Kill disengaged</source>
      <translation type="unfinished">Kill disengaged</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16691824/message</name>
    <message>
      <source>Ignoring mission item, invalid item</source>
      <translation type="unfinished">Ignoring mission item, invalid item</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/16725343/message</name>
    <message>
      <source>RTL: completed, loitering</source>
      <translation type="unfinished">RTL: completed, loitering</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1746622/message</name>
    <message>
      <source>Pilot took over using sticks</source>
      <translation type="unfinished">Pilot took over using sticks</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1801328/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, holding position</source>
      <translation type="unfinished">Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, holding position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1801328/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation type="unfinished">- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/185258/message</name>
    <message>
      <source>RTL: land at destination</source>
      <translation type="unfinished">RTL: land at destination</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1880909/message</name>
    <message>
      <source>Altitude change is outside geofence</source>
      <translation type="unfinished">Altitude change is outside geofence</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/1925166/message</name>
    <message>
      <source>Mission rejected: starts with landing</source>
      <translation type="unfinished">Mission rejected: starts with landing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2020940/message</name>
    <message>
      <source>Roll command reduced due to uncertain velocity/wind estimates!</source>
      <translation type="unfinished">Roll command reduced due to uncertain velocity/wind estimates!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2066387/message</name>
    <message>
      <source>Arming denied: calibrating</source>
      <translation type="unfinished">Arming denied: calibrating</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2087806/message</name>
    <message>
      <source>Orbit radius limit exceeded</source>
      <translation type="unfinished">Orbit radius limit exceeded</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2308551/message</name>
    <message>
      <source>Low remaining flight time, return advised</source>
      <translation type="unfinished">Low remaining flight time, return advised</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2321600/message</name>
    <message>
      <source>Already higher than takeoff altitude (not descending)</source>
      <translation type="unfinished">Already higher than takeoff altitude (not descending)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2440093/message</name>
    <message>
      <source>Unsupported ARM_DISARM param: {1:.3}</source>
      <translation type="unfinished">Unsupported ARM_DISARM param: {1:.3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2474944/message</name>
    <message>
      <source>Critical battery level, land now</source>
      <translation type="unfinished">Critical battery level, land now</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2566971/message</name>
    <message>
      <source>Disabling transmitting with IRIDIUM mavlink on instance {1} by command</source>
      <translation type="unfinished">Disabling transmitting with IRIDIUM mavlink on instance {1} by command</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2659830/message</name>
    <message>
      <source>Waypoint index eceeds list capacity (maximum: {1})</source>
      <translation type="unfinished">Waypoint index eceeds list capacity (maximum: {1})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2754873/message</name>
    <message>
      <source>Mission upload busy, ignoring MISSION_COUNT</source>
      <translation type="unfinished">Mission upload busy, ignoring MISSION_COUNT</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2768743/message</name>
    <message>
      <source>Unsupported main mode</source>
      <translation type="unfinished">Unsupported main mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2769710/message</name>
    <message>
      <source>Mission rejected: Add Landing item or remove Takeoff</source>
      <translation type="unfinished">Mission rejected: Add Landing item or remove Takeoff</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2831661/message</name>
    <message>
      <source>Geofence violation for waypoint {1}</source>
      <translation type="unfinished">Geofence violation for waypoint {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/2842608/message</name>
    <message>
      <source>Mission rejected: Landing waypoint/pattern required</source>
      <translation type="unfinished">Mission rejected: Landing waypoint/pattern required</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3038268/message</name>
    <message>
      <source>Received unknown mission type, abort</source>
      <translation type="unfinished">Received unknown mission type, abort</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3092229/message</name>
    <message>
      <source>Unsupported auto mode</source>
      <translation type="unfinished">Unsupported auto mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3198435/message</name>
    <message>
      <source>Mission rejected: the approach waypoint must be above the landing point</source>
      <translation type="unfinished">Mission rejected: the approach waypoint must be above the landing point</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3237806/message</name>
    <message>
      <source>Landing, flaring</source>
      <translation type="unfinished">Landing, flaring</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3321936/message</name>
    <message>
      <source>Waypoint index out of bounds (current {1} \&gt;= total {2})</source>
      <translation type="unfinished">Waypoint index out of bounds (current {1} \&gt;= total {2})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3322590/message</name>
    <message>
      <source>Landing at current position</source>
      <translation type="unfinished">Landing at current position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3329221/message</name>
    <message>
      <source>Remote ID system regained</source>
      <translation type="unfinished">Remote ID system regained</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3357977/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RA_MAX_STR_ANG</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RA_MAX_STR_ANG</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3378258/message</name>
    <message>
      <source>Mission rejected: No home position, waypoint {1} uses relative altitude</source>
      <translation type="unfinished">Mission rejected: No home position, waypoint {1} uses relative altitude</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3390156/message</name>
    <message>
      <source>No valid mission available, loitering</source>
      <translation type="unfinished">No valid mission available, loitering</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3453129/message</name>
    <message>
      <source>Geofence requires a valid home position</source>
      <translation type="unfinished">Geofence requires a valid home position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/346311/message</name>
    <message>
      <source>Launch detection running</source>
      <translation type="unfinished">Launch detection running</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3484900/message</name>
    <message>
      <source>Returning to launch</source>
      <translation type="unfinished">Returning to launch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3623245/message</name>
    <message>
      <source>Invalid configuration: Airspeed max smaller than min</source>
      <translation type="unfinished">Invalid configuration: Airspeed max smaller than min</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3623245/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</source>
      <translation type="unfinished">- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3645914/message</name>
    <message>
      <source>High latency data link lost</source>
      <translation type="unfinished">High latency data link lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3779911/message</name>
    <message>
      <source>Hover thrust has been constrained by min/max thrust</source>
      <translation type="unfinished">Hover thrust has been constrained by min/max thrust</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3779911/description</name>
    <message>
      <source>&lt;param&gt;MPC_THR_HOVER&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_THR_HOVER&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3817890/message</name>
    <message>
      <source>Invalid mission state</source>
      <translation type="unfinished">Invalid mission state</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3817890/description</name>
    <message>
      <source>No mission or storage failure</source>
      <translation type="unfinished">No mission or storage failure</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3878855/message</name>
    <message>
      <source>Using default takeoff altitude: {1:.2m}</source>
      <translation type="unfinished">Using default takeoff altitude: {1:.2m}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3914228/message</name>
    <message>
      <source>Rejecting mission request command, component or system ID mismatch</source>
      <translation type="unfinished">Rejecting mission request command, component or system ID mismatch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3939705/message</name>
    <message>
      <source>Land tilt limit has been constrained by maximum tilt</source>
      <translation type="unfinished">Land tilt limit has been constrained by maximum tilt</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/3939705/description</name>
    <message>
      <source>&lt;param&gt;MPC_TILTMAX_LND&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_TILTMAX_LND&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4075829/message</name>
    <message>
      <source>Provided autotune command is not supported. To enable autotune in mission, set param1 to 1</source>
      <translation type="unfinished">Provided autotune command is not supported. To enable autotune in mission, set param1 to 1</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4086702/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_P</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_P</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4089486/message</name>
    <message>
      <source>Rejecting waypoint command, component or system ID mismatch</source>
      <translation type="unfinished">Rejecting waypoint command, component or system ID mismatch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4163547/message</name>
    <message>
      <source>Start loiter with fixed bank angle</source>
      <translation type="unfinished">Start loiter with fixed bank angle</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4202815/message</name>
    <message>
      <source>Ignoring mission clear command, busy</source>
      <translation type="unfinished">Ignoring mission clear command, busy</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4277609/message</name>
    <message>
      <source>Takeoff detected</source>
      <translation type="unfinished">Takeoff detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/439666/message</name>
    <message>
      <source>Ignoring mission item, no transfer in progress</source>
      <translation type="unfinished">Ignoring mission item, no transfer in progress</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4502496/message</name>
    <message>
      <source>Failsafe activated: switching to {2} in {3} seconds</source>
      <translation type="unfinished">Failsafe activated: switching to {2} in {3} seconds</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4519150/message</name>
    <message>
      <source>Invalid configuration: Airspeed trim out of min or max bounds</source>
      <translation type="unfinished">Invalid configuration: Airspeed trim out of min or max bounds</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4519150/description</name>
    <message>
      <source>- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}
- &lt;param&gt;FW_AIRSPD_TRIM&lt;/param&gt;: {3:.1}</source>
      <translation type="unfinished">- &lt;param&gt;FW_AIRSPD_MAX&lt;/param&gt;: {1:.1}
- &lt;param&gt;FW_AIRSPD_MIN&lt;/param&gt;: {2:.1}
- &lt;param&gt;FW_AIRSPD_TRIM&lt;/param&gt;: {3:.1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4535132/message</name>
    <message>
      <source>logging: opening log file sess{1}/log{2}.ulg</source>
      <translation type="unfinished">logging: opening log file sess{1}/log{2}.ulg</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4678390/message</name>
    <message>
      <source>Mission finished, loitering</source>
      <translation type="unfinished">Mission finished, loitering</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4704426/message</name>
    <message>
      <source>Geofence imported</source>
      <translation type="unfinished">Geofence imported</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4774181/message</name>
    <message>
      <source>Mission rejected: the landing glide slope is steeper than the vehicle setting of {1}.{2} degrees</source>
      <translation type="unfinished">Mission rejected: the landing glide slope is steeper than the vehicle setting of {1}.{2} degrees</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4790285/message</name>
    <message>
      <source>Traffic Conflict Resolved {1}!</source>
      <translation type="unfinished">Traffic Conflict Resolved {1}!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4796299/message</name>
    <message>
      <source>Mission upload busy, already receiving waypoint</source>
      <translation type="unfinished">Mission upload busy, already receiving waypoint</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4854315/message</name>
    <message>
      <source>No valid mission available, refusing takeoff</source>
      <translation type="unfinished">No valid mission available, refusing takeoff</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4934924/message</name>
    <message>
      <source>Gyro {1} clipping, not safe to fly!</source>
      <translation type="unfinished">Gyro {1} clipping, not safe to fly!</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/4934924/description</name>
    <message>
      <source>Land now, and check the vehicle setup. Clipping can lead to fly-aways.</source>
      <translation type="unfinished">Land now, and check the vehicle setup. Clipping can lead to fly-aways.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5063943/message</name>
    <message>
      <source>Error saving settings</source>
      <translation type="unfinished">Error saving settings</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5065788/message</name>
    <message>
      <source>Manual sideways speed has been constrained by forward speed</source>
      <translation type="unfinished">Manual sideways speed has been constrained by forward speed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5065788/description</name>
    <message>
      <source>&lt;param&gt;MPC_VEL_MAN_SIDE&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_VEL_MAN_SIDE&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5108026/message</name>
    <message>
      <source>ESCs calibration denied</source>
      <translation type="unfinished">ESCs calibration denied</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/51327/message</name>
    <message>
      <source>Emergency battery level, land immediately</source>
      <translation type="unfinished">Emergency battery level, land immediately</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5137632/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_SPEED_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_SPEED_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5158211/message</name>
    <message>
      <source>No airspeed sensor detected, switching to non-airspeed mode</source>
      <translation type="unfinished">No airspeed sensor detected, switching to non-airspeed mode</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5314313/message</name>
    <message>
      <source>First waypoint far away from Home: {1m} Correct mission loaded?</source>
      <translation type="unfinished">First waypoint far away from Home: {1m} Correct mission loaded?</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5314313/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;MIS_DIST_1WP&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;MIS_DIST_1WP&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5371654/message</name>
    <message>
      <source>Magnetometer sensor #{1} failure: {2}</source>
      <translation>磁力计传感器 #{1} 失败： {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5371654/description</name>
    <message>
      <source>Land immediately and check the system.</source>
      <translation type="unfinished">Land immediately and check the system.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5383828/message</name>
    <message>
      <source>RTL: start return at {1m_v} ({2m_v} above destination)</source>
      <translation type="unfinished">RTL: start return at {1m_v} ({2m_v} above destination)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5494498/message</name>
    <message>
      <source>Mission rejected: Takeoff waypoint required</source>
      <translation type="unfinished">Mission rejected: Takeoff waypoint required</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5623108/message</name>
    <message>
      <source>Manual control lost</source>
      <translation type="unfinished">Manual control lost</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5650341/message</name>
    <message>
      <source>SET_POSITION_TARGET_LOCAL_NED: invalid, missing position, velocity or acceleration</source>
      <translation type="unfinished">SET_POSITION_TARGET_LOCAL_NED: invalid, missing position, velocity or acceleration</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5726704/message</name>
    <message>
      <source>High wind speed detected ({1:.1m/s}), landing advised</source>
      <translation type="unfinished">High wind speed detected ({1:.1m/s}), landing advised</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5734437/message</name>
    <message>
      <source>Command denied during calibration: {1}</source>
      <translation type="unfinished">Command denied during calibration: {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5795201/message</name>
    <message>
      <source>Geofence requires a valid home position</source>
      <translation type="unfinished">Geofence requires a valid home position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5814991/message</name>
    <message>
      <source>Ascent speed has been constrained by max speed</source>
      <translation type="unfinished">Ascent speed has been constrained by max speed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5814991/description</name>
    <message>
      <source>&lt;param&gt;MPC_Z_V_AUTO_UP&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_Z_V_AUTO_UP&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5847165/message</name>
    <message>
      <source>Dangerously low battery! System shut down failed</source>
      <translation type="unfinished">Dangerously low battery! System shut down failed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5847165/description</name>
    <message>
      <source>Cannot shut down, most likely the system does not support it.</source>
      <translation type="unfinished">Cannot shut down, most likely the system does not support it.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/5911339/message</name>
    <message>
      <source>Received unknown mission type, abort</source>
      <translation type="unfinished">Received unknown mission type, abort</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6006807/message</name>
    <message>
      <source>Quad-chute triggered due to maximum pitch angle exceeded</source>
      <translation type="unfinished">Quad-chute triggered due to maximum pitch angle exceeded</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6124520/message</name>
    <message>
      <source>Mission rejected: starts with landing</source>
      <translation type="unfinished">Mission rejected: starts with landing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/613779/message</name>
    <message>
      <source>Mission rejected: unsupported landing approach entrance waypoint type. Only ORBIT_TO_ALT or WAYPOINT allowed</source>
      <translation type="unfinished">Mission rejected: unsupported landing approach entrance waypoint type. Only ORBIT_TO_ALT or WAYPOINT allowed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/621270/message</name>
    <message>
      <source>Arm stick gesture disabled if arm switch in use</source>
      <translation type="unfinished">Arm stick gesture disabled if arm switch in use</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/621270/description</name>
    <message>
      <source>&lt;param&gt;MAN_ARM_GESTURE&lt;/param&gt; is now set to disable arm/disarm stick gesture.</source>
      <translation type="unfinished">&lt;param&gt;MAN_ARM_GESTURE&lt;/param&gt; is now set to disable arm/disarm stick gesture.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6349555/message</name>
    <message>
      <source>Calibration: Restoring RC input</source>
      <translation type="unfinished">Calibration: Restoring RC input</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6363289/message</name>
    <message>
      <source>Airspeed estimation valid</source>
      <translation type="unfinished">Airspeed estimation valid</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6415112/message</name>
    <message>
      <source>RC trim calibration completed</source>
      <translation type="unfinished">RC trim calibration completed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6843301/message</name>
    <message>
      <source>Parachute system regained</source>
      <translation type="unfinished">Parachute system regained</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6847604/message</name>
    <message>
      <source>Quad-chute triggered due to maximum roll angle exceeded</source>
      <translation type="unfinished">Quad-chute triggered due to maximum roll angle exceeded</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6880628/message</name>
    <message>
      <source>Approaching max flight time (system will RTL in {1} minutes)</source>
      <translation type="unfinished">Approaching max flight time (system will RTL in {1} minutes)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6880628/description</name>
    <message>
      <source>Maximal flight time warning (more than 1min remaining)</source>
      <translation type="unfinished">Maximal flight time warning (more than 1min remaining)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6922012/message</name>
    <message>
      <source>DO JUMP waypoint could not be written</source>
      <translation type="unfinished">DO JUMP waypoint could not be written</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/6974862/message</name>
    <message>
      <source>Unexpected waypoint index, aborting transfer</source>
      <translation type="unfinished">Unexpected waypoint index, aborting transfer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/697858/message</name>
    <message>
      <source>RC trim calibration: failed to set parameters</source>
      <translation type="unfinished">RC trim calibration: failed to set parameters</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7015692/message</name>
    <message>
      <source>Rejecting mission item, component or system ID mismatch</source>
      <translation type="unfinished">Rejecting mission item, component or system ID mismatch</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7028282/message</name>
    <message>
      <source>Airspeed sensor failure detected. Check connection and reboot</source>
      <translation type="unfinished">Airspeed sensor failure detected. Check connection and reboot</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7067274/message</name>
    <message>
      <source>Mission start denied! No valid mission</source>
      <translation type="unfinished">Mission start denied! No valid mission</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/710679/message</name>
    <message>
      <source>Mission failure: unable to reach heading within timeout</source>
      <translation type="unfinished">Mission failure: unable to reach heading within timeout</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/713405/message</name>
    <message>
      <source>Manual control regained after {1:.1} s</source>
      <translation type="unfinished">Manual control regained after {1:.1} s</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7144644/message</name>
    <message>
      <source>Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, landing</source>
      <translation type="unfinished">Traffic alert - ICAO Address {1}! Separation Distance {2}, Heading {3}, landing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7144644/description</name>
    <message>
      <source>- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</source>
      <translation type="unfinished">- ICAO Address: {1}
- Traffic Separation Distance: {2m}
- Heading: {3} degrees</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7186357/message</name>
    <message>
      <source>Yaw Airmode requires disabling the stick arm gesture</source>
      <translation type="unfinished">Yaw Airmode requires disabling the stick arm gesture</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7186357/description</name>
    <message>
      <source>&lt;param&gt;MC_AIRMODE&lt;/param&gt; is now set to roll/pitch airmode.</source>
      <translation type="unfinished">&lt;param&gt;MC_AIRMODE&lt;/param&gt; is now set to roll/pitch airmode.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/73581/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_YAW_RATE_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_YAW_RATE_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7364518/message</name>
    <message>
      <source>Invalid configuration for rate control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_YAW_RATE_P) is setup</source>
      <translation type="unfinished">Invalid configuration for rate control: Neither feed forward (RO_MAX_THR_SPEED) nor feedback (RO_YAW_RATE_P) is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7714236/message</name>
    <message>
      <source>Approaching max flight time (system will RTL in {1} seconds)</source>
      <translation type="unfinished">Approaching max flight time (system will RTL in {1} seconds)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7714236/description</name>
    <message>
      <source>Maximal flight time warning (less than 1min remaining)</source>
      <translation type="unfinished">Maximal flight time warning (less than 1min remaining)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7791755/message</name>
    <message>
      <source>Airspeed sensor healthy, start using again</source>
      <translation type="unfinished">Airspeed sensor healthy, start using again</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7791755/description</name>
    <message>
      <source>Previously selected sensor index: {1}, current sensor index: {2}.</source>
      <translation type="unfinished">Previously selected sensor index: {1}, current sensor index: {2}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7803396/message</name>
    <message>
      <source>Mission finished, landed</source>
      <translation type="unfinished">Mission finished, landed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7832778/message</name>
    <message>
      <source>Traffic Conflict {1} Expired and removed from buffer</source>
      <translation type="unfinished">Traffic Conflict {1} Expired and removed from buffer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7853111/message</name>
    <message>
      <source>Invalid configuration of necessary parameter RO_SPEED_LIM</source>
      <translation type="unfinished">Invalid configuration of necessary parameter RO_SPEED_LIM</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7860665/message</name>
    <message>
      <source>Mission rejected: land start item before RTL item is not possible</source>
      <translation type="unfinished">Mission rejected: land start item before RTL item is not possible</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/7939557/message</name>
    <message>
      <source>Invalid configuration for rate control: Neither feed forward nor feedback is setup</source>
      <translation type="unfinished">Invalid configuration for rate control: Neither feed forward nor feedback is setup</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8208988/message</name>
    <message>
      <source>Climb to {1:.1m_v} above home</source>
      <translation type="unfinished">Climb to {1:.1m_v} above home</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8280920/message</name>
    <message>
      <source>Airspeed estimation invalid</source>
      <translation type="unfinished">Airspeed estimation invalid</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8310204/message</name>
    <message>
      <source>Landing using precision landing</source>
      <translation type="unfinished">Landing using precision landing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8324861/message</name>
    <message>
      <source>Not yet ready for mission, no position lock</source>
      <translation type="unfinished">Not yet ready for mission, no position lock</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8459921/message</name>
    <message>
      <source>Mission rejected: Landing waypoint/pattern required</source>
      <translation type="unfinished">Mission rejected: Landing waypoint/pattern required</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8546752/message</name>
    <message>
      <source>Ignoring mission item, busy</source>
      <translation type="unfinished">Ignoring mission item, busy</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8557551/message</name>
    <message>
      <source>Failsafe warning: {2}</source>
      <translation type="unfinished">Failsafe warning: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8557551/description</name>
    <message>
      <source>No action is triggered.</source>
      <translation type="unfinished">No action is triggered.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8673473/message</name>
    <message>
      <source>Not enough bandwidth to enable log streaming ({1} \&lt; 5000)</source>
      <translation type="unfinished">Not enough bandwidth to enable log streaming ({1} \&lt; 5000)</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8706060/message</name>
    <message>
      <source>Manual backward speed has been constrained by forward speed</source>
      <translation type="unfinished">Manual backward speed has been constrained by forward speed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8706060/description</name>
    <message>
      <source>&lt;param&gt;MPC_VEL_MAN_BACK&lt;/param&gt; is set to {1:.0}.</source>
      <translation type="unfinished">&lt;param&gt;MPC_VEL_MAN_BACK&lt;/param&gt; is set to {1:.0}.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8775715/message</name>
    <message>
      <source>Mission rejected: item {1}: unsupported command: {2}</source>
      <translation type="unfinished">Mission rejected: item {1}: unsupported command: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8833276/message</name>
    <message>
      <source>No inputs, aborting RC trim calibration</source>
      <translation type="unfinished">No inputs, aborting RC trim calibration</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8865457/message</name>
    <message>
      <source>Geofence: import error</source>
      <translation type="unfinished">Geofence: import error</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8894709/message</name>
    <message>
      <source>Mission rejected: the landing point must be outside the orbit radius</source>
      <translation type="unfinished">Mission rejected: the landing point must be outside the orbit radius</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/8935528/message</name>
    <message>
      <source>Mission manager currently busy, ignoring new waypoint index</source>
      <translation type="unfinished">Mission manager currently busy, ignoring new waypoint index</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9013084/message</name>
    <message>
      <source>Ignoring mission request, currently busy</source>
      <translation type="unfinished">Ignoring mission request, currently busy</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9091509/message</name>
    <message>
      <source>Disarming denied: not landed</source>
      <translation type="unfinished">Disarming denied: not landed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9092852/message</name>
    <message>
      <source>Unexpected waypoint index, aborting mission transfer</source>
      <translation type="unfinished">Unexpected waypoint index, aborting mission transfer</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9180535/message</name>
    <message>
      <source>GNSS signal spoofed</source>
      <translation type="unfinished">GNSS signal spoofed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/929525/message</name>
    <message>
      <source>Estimated position error is approaching the failsafe threshold</source>
      <translation type="unfinished">Estimated position error is approaching the failsafe threshold</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/929525/description</name>
    <message>
      <source>Switch to manual mode recommended.

&lt;profile name="dev"&gt; This warning is triggered when the position error estimate is 90% of (or only 10m below) &lt;param&gt;COM_POS_FS_EPH&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Switch to manual mode recommended.

&lt;profile name="dev"&gt; This warning is triggered when the position error estimate is 90% of (or only 10m below) &lt;param&gt;COM_POS_FS_EPH&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9346577/message</name>
    <message>
      <source>Reached clearance altitude</source>
      <translation type="unfinished">Reached clearance altitude</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9351472/message</name>
    <message>
      <source>RTL: unsupported MAV_FRAME ({1})</source>
      <translation type="unfinished">RTL: unsupported MAV_FRAME ({1})</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9355528/message</name>
    <message>
      <source>Could not set mission closest to position</source>
      <translation type="unfinished">Could not set mission closest to position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9421773/message</name>
    <message>
      <source>Baro sensor #{1} failure: {2}</source>
      <translation type="unfinished">Baro sensor #{1} failure: {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9421773/description</name>
    <message>
      <source>Land immediately and check the system.</source>
      <translation type="unfinished">Land immediately and check the system.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9427265/message</name>
    <message>
      <source>Mission could not reset jump count</source>
      <translation type="unfinished">Mission could not reset jump count</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9432105/message</name>
    <message>
      <source>Geofence invalid, doesn't contain current vehicle position</source>
      <translation type="unfinished">Geofence invalid, doesn't contain current vehicle position</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9476947/message</name>
    <message>
      <source>Quad-chute triggered due to uncommanded descent detection</source>
      <translation type="unfinished">Quad-chute triggered due to uncommanded descent detection</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9489139/message</name>
    <message>
      <source>Armed by {1}</source>
      <translation type="unfinished">Armed by {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9537079/message</name>
    <message>
      <source>Obstacle message received in unsupported frame {1}</source>
      <translation type="unfinished">Obstacle message received in unsupported frame {1}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/961599/message</name>
    <message>
      <source>Pilot took over using sticks</source>
      <translation type="unfinished">Pilot took over using sticks</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9621455/message</name>
    <message>
      <source>5V overcurrent detected, landing advised</source>
      <translation type="unfinished">5V overcurrent detected, landing advised</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9751178/message</name>
    <message>
      <source>{3}: switching to {2}</source>
      <translation type="unfinished">{3}: switching to {2}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9758530/message</name>
    <message>
      <source>Mission item could not be set</source>
      <translation type="unfinished">Mission item could not be set</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9828325/message</name>
    <message>
      <source>GNSS signal jammed</source>
      <translation type="unfinished">GNSS signal jammed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/default/events/9844908/message</name>
    <message>
      <source>Landing detected</source>
      <translation type="unfinished">Landing detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/10318274/message</name>
    <message>
      <source>Battery {3} missing</source>
      <translation type="unfinished">Battery {3} missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/10318274/description</name>
    <message>
      <source>Make sure all required batteries are connected.</source>
      <translation type="unfinished">Make sure all required batteries are connected.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1058956/message</name>
    <message>
      <source>CPU load too high: {3:.1}%</source>
      <translation type="unfinished">CPU load too high: {3:.1}%</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1058956/description</name>
    <message>
      <source>The CPU load can be reduced for example by disabling unused modules (e.g. mavlink instances) or reducing the gyro update rate via &lt;param&gt;IMU_GYRO_RATEMAX&lt;/param&gt;.

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_CPU_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The CPU load can be reduced for example by disabling unused modules (e.g. mavlink instances) or reducing the gyro update rate via &lt;param&gt;IMU_GYRO_RATEMAX&lt;/param&gt;.

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_CPU_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/11125932/message</name>
    <message>
      <source>No valid data from optical flow sensor</source>
      <translation type="unfinished">No valid data from optical flow sensor</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/11478328/message</name>
    <message>
      <source>No valid data from Gyro {3}</source>
      <translation type="unfinished">No valid data from Gyro {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13344346/message</name>
    <message>
      <source>Battery unhealthy</source>
      <translation type="unfinished">Battery unhealthy</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13344346/description</name>
    <message>
      <source>Make sure all batteries are operational.</source>
      <translation type="unfinished">Make sure all batteries are operational.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13372152/message</name>
    <message>
      <source>Parachute system not ready</source>
      <translation type="unfinished">Parachute system not ready</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/13372152/description</name>
    <message>
      <source>MAVLink parachute system reports unhealthy status.

&lt;profile name="dev"&gt; Enabled by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</source>
      <translation type="unfinished">MAVLink parachute system reports unhealthy status.

&lt;profile name="dev"&gt; Enabled by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14221469/message</name>
    <message>
      <source>Distance sensor {3} missing</source>
      <translation type="unfinished">Distance sensor {3} missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14221469/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_NUM_DIST&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_NUM_DIST&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14421482/message</name>
    <message>
      <source>RAM usage too high: {3:.1}%</source>
      <translation type="unfinished">RAM usage too high: {3:.1}%</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14421482/description</name>
    <message>
      <source>The RAM usage can be reduced for example by disabling unused modules (e.g. mavlink instances).

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_RAM_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The RAM usage can be reduced for example by disabling unused modules (e.g. mavlink instances).

&lt;profile name="dev"&gt; The threshold can be adjusted via &lt;param&gt;COM_RAM_MAX&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14566046/message</name>
    <message>
      <source>ESC {3} offline</source>
      <translation type="unfinished">ESC {3} offline</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/14566046/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15289843/message</name>
    <message>
      <source>Avionics Power high: {3:.2} Volt</source>
      <translation type="unfinished">Avionics Power high: {3:.2} Volt</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15289843/description</name>
    <message>
      <source>Check the voltage supply to the FMU, it must be below {4:.2} Volt.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Check the voltage supply to the FMU, it must be below {4:.2} Volt.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15388760/message</name>
    <message>
      <source>Compass sensor {3} missing</source>
      <translation type="unfinished">Compass sensor {3} missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15602498/message</name>
    <message>
      <source>Battery {3}: {4}. {5}</source>
      <translation type="unfinished">Battery {3}: {4}. {5}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15602498/description</name>
    <message>
      <source>The battery reported a failure which might be dangerous to fly with.</source>
      <translation type="unfinished">The battery reported a failure which might be dangerous to fly with.</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15793174/message</name>
    <message>
      <source>ESC {3}: {4}</source>
      <translation type="unfinished">ESC {3}: {4}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15793174/description</name>
    <message>
      <source>{5}

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">{5}

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15965684/message</name>
    <message>
      <source>Parachute system missing</source>
      <translation type="unfinished">Parachute system missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/15965684/description</name>
    <message>
      <source>No MAVLink parachute heartbeat detected. Check connection, power, configuration.

&lt;profile name="dev"&gt; Enabled by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</source>
      <translation type="unfinished">No MAVLink parachute heartbeat detected. Check connection, power, configuration.

&lt;profile name="dev"&gt; Enabled by &lt;param&gt;COM_PARACHUTE&lt;/param&gt;
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/16230031/message</name>
    <message>
      <source>No valid data from Accelerometer {3}</source>
      <translation type="unfinished">No valid data from Accelerometer {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1670367/message</name>
    <message>
      <source>Avionics Power low: {3:.2} Volt</source>
      <translation type="unfinished">Avionics Power low: {3:.2} Volt</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1670367/description</name>
    <message>
      <source>Check the voltage supply to the FMU, it must be above {4:.2} Volt.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Check the voltage supply to the FMU, it must be above {4:.2} Volt.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/1914663/message</name>
    <message>
      <source>Health report summary event</source>
      <translation type="unfinished">Health report summary event</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3081997/message</name>
    <message>
      <source>Motor {3} overcurrent detected</source>
      <translation type="unfinished">Motor {3} overcurrent detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3081997/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3189229/message</name>
    <message>
      <source>No valid data from barometer {3}</source>
      <translation type="unfinished">No valid data from barometer {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/3568720/message</name>
    <message>
      <source>Gyro sensor {3} missing</source>
      <translation type="unfinished">Gyro sensor {3} missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4448091/message</name>
    <message>
      <source>Crash dumps present on SD card</source>
      <translation type="unfinished">Crash dumps present on SD card</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4448091/description</name>
    <message>
      <source>The SD card contains crash dump files, service the vehicle before continuing to fly.

&lt;profile name="dev"&gt; Check how to debug hardfaults on &lt;a&gt;https://docs.px4.io/main/en/debug/gdb_debugging.html#hard-fault-debugging&lt;/a&gt;. When completed, remove the files 'fault_*.log' on the SD card.

This check can be configured via &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The SD card contains crash dump files, service the vehicle before continuing to fly.

&lt;profile name="dev"&gt; Check how to debug hardfaults on &lt;a&gt;https://docs.px4.io/main/en/debug/gdb_debugging.html#hard-fault-debugging&lt;/a&gt;. When completed, remove the files 'fault_*.log' on the SD card.

This check can be configured via &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4643123/message</name>
    <message>
      <source>Airspeed invalid</source>
      <translation type="unfinished">Airspeed invalid</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4877352/message</name>
    <message>
      <source>Imbalanced propeller detected</source>
      <translation type="unfinished">Imbalanced propeller detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/4877352/description</name>
    <message>
      <source>Check that all propellers are mounted correctly and are not damaged.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_IMB_PROP_THR&lt;/param&gt; and &lt;param&gt;COM_IMB_PROP_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</source>
      <translation type="unfinished">Check that all propellers are mounted correctly and are not damaged.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_IMB_PROP_THR&lt;/param&gt; and &lt;param&gt;COM_IMB_PROP_ACT&lt;/param&gt; parameters.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/5095593/message</name>
    <message>
      <source>Barometer {3} missing</source>
      <translation type="unfinished">Barometer {3} missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/5699115/message</name>
    <message>
      <source>Overcurrent detected for the peripheral 5V supply</source>
      <translation type="unfinished">Overcurrent detected for the peripheral 5V supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/5699115/description</name>
    <message>
      <source>Check the power supply</source>
      <translation type="unfinished">Check the power supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6410608/message</name>
    <message>
      <source>No valid data from Compass {3}</source>
      <translation type="unfinished">No valid data from Compass {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6443801/message</name>
    <message>
      <source>Motor {3} undercurrent detected</source>
      <translation type="unfinished">Motor {3} undercurrent detected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6443801/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;FD_ACT_EN&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6632208/message</name>
    <message>
      <source>Not all ESCs are armed</source>
      <translation type="unfinished">Not all ESCs are armed</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6632208/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6962647/message</name>
    <message>
      <source>Overcurrent detected for the hipower 5V supply</source>
      <translation type="unfinished">Overcurrent detected for the hipower 5V supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/6962647/description</name>
    <message>
      <source>Check the power supply</source>
      <translation type="unfinished">Check the power supply</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7214714/message</name>
    <message>
      <source>System power unavailable</source>
      <translation type="unfinished">System power unavailable</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7214714/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Ensure the ADC is working and the system_power topic is published.

This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Ensure the ADC is working and the system_power topic is published.

This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7908333/message</name>
    <message>
      <source>Power module not connected</source>
      <translation type="unfinished">Power module not connected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/7908333/description</name>
    <message>
      <source>Note that USB must be disconnected as well.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">Note that USB must be disconnected as well.

&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;CBRK_SUPPLY_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8227839/message</name>
    <message>
      <source>Accelerometer sensor {3} missing</source>
      <translation type="unfinished">Accelerometer sensor {3} missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8544646/message</name>
    <message>
      <source>No valid data from distance sensor {3}</source>
      <translation type="unfinished">No valid data from distance sensor {3}</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8792768/message</name>
    <message>
      <source>Optical flow sensor missing</source>
      <translation type="unfinished">Optical flow sensor missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8792768/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_NUM_OF&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;SYS_HAS_NUM_OF&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/8799553/message</name>
    <message>
      <source>Battery {3} disconnected</source>
      <translation type="unfinished">Battery {3} disconnected</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9191449/message</name>
    <message>
      <source>ESC telemetry missing</source>
      <translation type="unfinished">ESC telemetry missing</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9191449/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; This check can be configured via &lt;param&gt;COM_ARM_CHK_ESCS&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9266821/message</name>
    <message>
      <source>No CPU and RAM load information</source>
      <translation type="unfinished">No CPU and RAM load information</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9266821/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; If the system does not provide any CPU and RAM load information, use the parameters &lt;param&gt;COM_CPU_MAX&lt;/param&gt; and &lt;param&gt;COM_RAM_MAX&lt;/param&gt; to disable the checks.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; If the system does not provide any CPU and RAM load information, use the parameters &lt;param&gt;COM_CPU_MAX&lt;/param&gt; and &lt;param&gt;COM_RAM_MAX&lt;/param&gt; to disable the checks.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9409869/message</name>
    <message>
      <source>Task watchdog dumps present on SD card</source>
      <translation type="unfinished">Task watchdog dumps present on SD card</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9409869/description</name>
    <message>
      <source>The SD card contains task watchdog dump files from a previous task starvation event.

&lt;profile name="dev"&gt; Remove the files in the 'task_watchdog' directory on the SD card after analysis.

This check can be configured via &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">The SD card contains task watchdog dump files from a previous task starvation event.

&lt;profile name="dev"&gt; Remove the files in the 'task_watchdog' directory on the SD card after analysis.

This check can be configured via &lt;param&gt;COM_ARM_HFLT_CHK&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9493632/message</name>
    <message>
      <source>No airspeed data</source>
      <translation type="unfinished">No airspeed data</translation>
    </message>
  </context>
  <context>
    <name>/components/1/event_groups/health/events/9493632/description</name>
    <message>
      <source>&lt;profile name="dev"&gt; Most likely the airspeed selector module is not running. This check can be configured via &lt;param&gt;SYS_HAS_NUM_ASPD&lt;/param&gt; parameter.
&lt;/profile&gt;</source>
      <translation type="unfinished">&lt;profile name="dev"&gt; Most likely the airspeed selector module is not running. This check can be configured via &lt;param&gt;SYS_HAS_NUM_ASPD&lt;/param&gt; parameter.
&lt;/profile&gt;</translation>
    </message>
  </context>
</TS>
